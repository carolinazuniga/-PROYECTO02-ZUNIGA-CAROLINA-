{
 "cells": [
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# Proyecto 2\n",
    "\n",
    "### INTRODUCCIÓN AL ANÁLISIS DE DATOS \n",
    "\n",
    "#### Por: Carolina Zúñiga Ramírez \n",
    "\n",
    "\n",
    "\n",
    "\n",
    "\n",
    ".\n"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Importación de librerías: pandas, numpy, matplotlib y seaborn. "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 2,
   "metadata": {},
   "outputs": [],
   "source": [
    "import warnings\n",
    "warnings.filterwarnings(\"ignore\")\n",
    "\n",
    "import pandas as pd\n",
    "import numpy as np\n",
    "import matplotlib.pyplot as plt \n",
    "import seaborn as sns "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 5,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>register_id</th>\n",
       "      <th>direction</th>\n",
       "      <th>origin</th>\n",
       "      <th>destination</th>\n",
       "      <th>year</th>\n",
       "      <th>date</th>\n",
       "      <th>product</th>\n",
       "      <th>transport_mode</th>\n",
       "      <th>company_name</th>\n",
       "      <th>total_value</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>1573</th>\n",
       "      <td>1574</td>\n",
       "      <td>Exports</td>\n",
       "      <td>USA</td>\n",
       "      <td>Brazil</td>\n",
       "      <td>2019</td>\n",
       "      <td>27/03/19</td>\n",
       "      <td>Aerospace Parts</td>\n",
       "      <td>Sea</td>\n",
       "      <td>Boeing Company</td>\n",
       "      <td>8000000</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>17330</th>\n",
       "      <td>17331</td>\n",
       "      <td>Imports</td>\n",
       "      <td>France</td>\n",
       "      <td>Germany</td>\n",
       "      <td>2015</td>\n",
       "      <td>09/05/15</td>\n",
       "      <td>Machinery and electronics</td>\n",
       "      <td>Road</td>\n",
       "      <td>Daimler Machinery  Inc</td>\n",
       "      <td>0</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>7718</th>\n",
       "      <td>7719</td>\n",
       "      <td>Exports</td>\n",
       "      <td>India</td>\n",
       "      <td>Russia</td>\n",
       "      <td>2017</td>\n",
       "      <td>13/06/17</td>\n",
       "      <td>Rice</td>\n",
       "      <td>Sea</td>\n",
       "      <td>Green India Ltd</td>\n",
       "      <td>2000000</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3319</th>\n",
       "      <td>3320</td>\n",
       "      <td>Exports</td>\n",
       "      <td>Japan</td>\n",
       "      <td>China</td>\n",
       "      <td>2018</td>\n",
       "      <td>10/06/18</td>\n",
       "      <td>Cars</td>\n",
       "      <td>Sea</td>\n",
       "      <td>Suzuki</td>\n",
       "      <td>2000000</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>11677</th>\n",
       "      <td>11678</td>\n",
       "      <td>Exports</td>\n",
       "      <td>Germany</td>\n",
       "      <td>USA</td>\n",
       "      <td>2020</td>\n",
       "      <td>08/02/20</td>\n",
       "      <td>Pharmaceuticals</td>\n",
       "      <td>Air</td>\n",
       "      <td>Bayer AG</td>\n",
       "      <td>17000</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "       register_id direction   origin destination  year      date  \\\n",
       "1573          1574   Exports      USA      Brazil  2019  27/03/19   \n",
       "17330        17331   Imports   France     Germany  2015  09/05/15   \n",
       "7718          7719   Exports    India      Russia  2017  13/06/17   \n",
       "3319          3320   Exports    Japan       China  2018  10/06/18   \n",
       "11677        11678   Exports  Germany         USA  2020  08/02/20   \n",
       "\n",
       "                         product transport_mode            company_name  \\\n",
       "1573             Aerospace Parts            Sea          Boeing Company   \n",
       "17330  Machinery and electronics           Road  Daimler Machinery  Inc   \n",
       "7718                        Rice            Sea         Green India Ltd   \n",
       "3319                        Cars            Sea                  Suzuki   \n",
       "11677            Pharmaceuticals            Air                Bayer AG   \n",
       "\n",
       "       total_value  \n",
       "1573       8000000  \n",
       "17330            0  \n",
       "7718       2000000  \n",
       "3319       2000000  \n",
       "11677        17000  "
      ]
     },
     "execution_count": 5,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "df= pd.read_csv('synergy_logistics_database.csv')\n",
    "df.sample(5)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "**Objetivo:** Elaborar una propuesta que permita enfocar las prioridades de la estrategia operativa para analizar viabilidad de 3 opciones:\n",
    "        \n",
    "  1. Rutas de importación y exportación. \n",
    "  2. Medio de Transporte utilizado. \n",
    "  3.Valor total de importaciones y exportaciones."
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### Rutas de importación y exportación \n",
    "\n",
    "1. Obtener el total de las exportaciones por cada país, de acuerdo a su origen.\n",
    "2. Obtener el total de las importaciones por cada país, de acuerdo a su origen.\n",
    "3. Revisar sus filas y hacer una conjunción de ambos procesos.\n",
    "4. Obtener los flujos. "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 47,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>origin</th>\n",
       "      <th>total_value</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>Australia</td>\n",
       "      <td>1650000000</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>Austria</td>\n",
       "      <td>1155000</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "      origin  total_value\n",
       "0  Australia   1650000000\n",
       "1    Austria      1155000"
      ]
     },
     "execution_count": 47,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "expor= df[df['direction']=='Exports']\n",
    "expor= expor.groupby('origin')['total_value'].sum()\n",
    "expor=pd.DataFrame(expor)\n",
    "expor.reset_index(inplace=True)\n",
    "expor.sort_values('total_value', ascending=False)\n",
    "expor.head(2)\n",
    "#Productos que salen del país \n",
    "\n",
    "#China*, Francia*, USA*, South Korea*, Russia, Japan*, Germany*, Canada, Italy, Netherlands "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 48,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>origin</th>\n",
       "      <th>total_value</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>Australia</td>\n",
       "      <td>920000000</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>Brazil</td>\n",
       "      <td>489000000</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "      origin  total_value\n",
       "0  Australia    920000000\n",
       "1     Brazil    489000000"
      ]
     },
     "execution_count": 48,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "impor= df[df['direction']=='Imports']\n",
    "impor= impor.groupby('origin')['total_value'].sum()\n",
    "impor=pd.DataFrame(impor)\n",
    "impor.reset_index(inplace=True)\n",
    "impor.sort_values('total_value', ascending=False)\n",
    "impor.head(2)\n",
    "#Productos que llegan de otro país \n",
    "\n",
    "#China*, Japan*, USA*, Mexico, Germany*, Singapore, South Korea*, Malaysia, España, Francia "
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Para el **flujo de importación y exportación**, recurriremos a la investigación de la balanza comercial, puesto que esta mide la diferencia entre las importaciones y exportaciones. \n",
    "\n",
    "Este flujo es exportaciones menos importacines ya que está directamente relacionado con el PIB (Producto Interno Bruto) de un país, siendo este calculado como: Consumo privado, más inversióm, más gasto público más exportaciones menos importaciones por lo que cuando las exportaciones son menores a las importaciones hay un **déficit en la balanza comercial**. "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 77,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>origin</th>\n",
       "      <th>total_value_expor</th>\n",
       "      <th>total_value_impor</th>\n",
       "      <th>balanza_comercial</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>5</th>\n",
       "      <td>China</td>\n",
       "      <td>3.297705e+10</td>\n",
       "      <td>1.223300e+10</td>\n",
       "      <td>2.074405e+10</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>6</th>\n",
       "      <td>France</td>\n",
       "      <td>1.861433e+10</td>\n",
       "      <td>1.316000e+09</td>\n",
       "      <td>1.729833e+10</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "   origin  total_value_expor  total_value_impor  balanza_comercial\n",
       "5   China       3.297705e+10       1.223300e+10       2.074405e+10\n",
       "6  France       1.861433e+10       1.316000e+09       1.729833e+10"
      ]
     },
     "execution_count": 77,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "balanza_c=pd.merge(expor,impor,on='origin',how='outer', suffixes=('_expor', '_impor'))\n",
    "balanza_c = balanza_c.fillna(0)\n",
    "balanza_c['balanza_comercial']= balanza_c['total_value_expor']- balanza_c['total_value_impor']\n",
    "order=balanza_c.sort_values('balanza_comercial', ascending=False)\n",
    "order.head(2)\n",
    "#Las Rutas Comerciales más importantes de acuerdo a su Flujo son:\n",
    "        #China, Francia, USA, Russia, South Korea, Canada, Germany, Netherlands, Italy, Japan"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 274,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "image/png": "iVBORw0KGgoAAAANSUhEUgAAAzAAAAH5CAYAAABecNtOAAAAOXRFWHRTb2Z0d2FyZQBNYXRwbG90bGliIHZlcnNpb24zLjMuMiwgaHR0cHM6Ly9tYXRwbG90bGliLm9yZy8vihELAAAACXBIWXMAAAsTAAALEwEAmpwYAABesElEQVR4nO3de7yl9dz/8ddbR5SoRkI1IbqTTLVDpCaRkEN0U3coItxCfo737VTcTrfTHaE76U5OUanIIYeMDjrtamoqKWUiRVOhg0qaz++P69pardaevffM3nvtNfN6Ph7rsa71vb7X9/pca609sz7re1ipKiRJkiRpENyv3wFIkiRJ0niZwEiSJEkaGCYwkiRJkgaGCYwkSZKkgWECI0mSJGlgmMBIkiRJGhgmMJIGVpJKcuQyHH9g28bsyYtq2SVZmGRev+PQPZLMbt8rB/Y7Fi1/ksxLsrDfcUiDwgRG0oySZG77QXG021P6HeOgGuN5rSTb9TvG8WoTigOTzOl3LCu6ji8Chvody2RJckCSffodh6TeVu53AJI0im8CP+hR/ptJPMd/AR8D7pzENme6+cCnRtn362mMY1nNBj4ALKS5pql2NXB/4B/TcC713wE0760jp+l8OwOZpnNJA88ERtJMdX5VfW0qT1BV/2DF+0D6h6l+XqdSkjWr6pbpPm9VFXDHdJ9X0yfJSsBqVfW36T53Vf19us8pDTKHkElabixpnkKv+S6jzYFp2/lqkj8luTPJlUk+kuQBXfXWTvKZdv8dSW5Mcl6Sd4wz3g2SfDvJX5PcnOR7SR69hPrPTPLjJH9pz3dRkteP51wTkeR5SRYn+XJX+RpJft0+Lw9ry0aG/O2T5E1JLm9juzzJm0Zpf/skP2mv+/Yk5yfZt0e9ee18oEclOTbJTcDN7dCen7fV/q9jCNy89rj7JXlPklOT/DHJ35P8LskXk6wzSkwvSfLz9rn9W3udn02yaru/53srycpJ3pXk0o73wPFJntBV75/HJ9k1yblt/euSfCLJfb5QTLJJ+z68rr2GhW3dB3bV2yDJEUmubt+v1yf5ZZK9e11rj/OsleTjSX7THr8oyTeTPGo8x4/S5j7t9e6U5P1tbLcnOTvtMNAkOyQ5Pclt7TW+r0c7C9v3wVZJTklya5KbknwlyUN71F83yeeT/L59zn7fPl6nq95IfM9M8r4kV9IkqC9NUsBGwA659xDL2e2xOyf5VpKr2mv6S5q/yx1GeS4ek+T/klzTxnRtkhOTbN1Rp+ccmEz8b+Xh7Wv35/Z5PTnJY3vUXy3Jfya5pH0f/iXNvz9bdtVLmuF0FyW5Jc2/U79O8uUkq/S6Xmk62AMjaaZ6QJJ1u8runOpv35NsBJwDrAV8EbgcmAv8B/C0JDu1PTcAxwDbA/8LXAg8ANi0rf+JMc7zYOBUYAPgUOBSYAeaD+b371F/v7beWcCHgduAZwFfTPLoqhpX0gSs0uN5haaT4cZ24/tJ/gd4a5KfVNXRbZ0vAJsAz6uqP3Yd/ybgYTTPxS3AnsBnk6xdVQd1XMfzgeOBP9IMZbsF2AM4PMmjquo9Xe2uAfwCOAN4D/BQmuftI8B/AocBp7V1/9Terwq8AzgOOJHmudoG2BfYLsnWnd94J/lw29alwGeA64BHAy8B3g8s6dvxrwMvBX5C8355GPBG4MwkT6+qC7rqPxf4d5rX8gjghcDbgT+31zQS09bAKcBfaJ7TPwBPBN5M8z7coaruSpP4/AR4BM3rcznNe3cL4OnAV5YQO0nWAn4JbNjGcwmwfhvj2UmGqurqJbUxho8BKwEH07wubwNObpOrL9O8fiPP4QeT/LZHD+EjgZ/RvJ7HAlsBrwaGkmwz0mPScS2Paa/lfGBL4A3AM5I8qce/H58EVgG+BNxMM4zyFTTvgxto/tZGLGrv9wHWBo4CrqF57l8D/CzJjlU18n4kzbygn7Xn+DJwcXvsDsBTgfNGe+KW4m/lgTR/G2fRvJ83Bt4CnJhk86q6u213FeBH7fm/ChxC8555LXBGku2rarht873AB4Hv0bxn727bfQGwGnDXaPFLU6qqvHnz5m3G3Gg+/Ncot6O76hZwZMfj2W3ZgT3aPbDdN3uMsq+3Zc/tOv4Tbfm+7eO12sdfWMrr/Eh7/Ku6yv+nLZ/XUbY+zbfD3+jRzsE0HyoePY5zjva8FnBrV91VgWHgr8CjgJe39T45yut1C/DIruPPofmA88i2bCWauSR/AR7eVfeM9jo26Sif17b9X0t4n+zTY1+A+/co37c95qUdZU9qy04BVu/RTkZ7b9EkkAV8a6ReW74FzdDE03q8N2/rer+F5kPtdV3nvhC4DFizq3y3zutuz1XAO5fyfXgwcDvwxK7yjWg+0B85jjYObGMY6ijbpy07H1i1o/wFbfk/gG263gPXAWd2tb2wrX9AV/lb2/J3d5R9uC379666b2zLP9Qjvl8DD+hxTQvp+Bvs2vfAHmXr0SQ8P+jx2t4BbNHjmPt1vdcXdjxe2r+Vd3ad4x1t+bN7PHfP7qr7IOB33PvfnvOBS5fmveXN21TeHEImaaY6jOYDYuftv6byhEnuR/MB64Kq6l5A4KPAYpoPkNB86LsTeHKWbhnmF9H0GBzVVf7xHnV3p/m288vtEJl/3mi+Gb0fsNM4z3s2931enwXs2lmpmh6Kl9F8CDuepndhmKYnqpevV9U1Xcd/hqan//lt8da03/RX1bVddT/RXscLe7T9yXFe20h7VVW3QzOvIcmD2+fqlLbKkzuq79Xe/0dV3dGjnVrCqUbeCx/urFdVFwEn0fT2zOo65oSqWth5Dppet4clWaON+Qk0ick3gNW6Xu/TaZKgndsm/tre79hrSNWSJAnN9Z8K/KHrPLfRfJO/85LaGIcv1r3nd4z0TpxVVeeOFLZ1zqHp4et2M837r9MX2vLdOsp2o+klOayr7v/SJBe7cV9frAnOeamq20a20wyrXIcmoTibe7+35gCPB/6vfU90t7N4CadZmr+VxcBnu8pG3vOdz+vLaZLj87pe81VpevO2SzLSC/xX4BEZoBUKtWJwCJmkmeqKqvrpNJ9zFs2QpUu6d1TVTUmuo+mNoKr+nuQAmm+wf5vkUpoPCydU1c/Gca5HAedWO6yj4zzXJflLV91/ae+X9HysN45zAtww3ue1qq5M8v9ohtfcDuxZVaMNGflVj7JL2/uRuRQbt/f3eX5pvqnurDtiUVX9ZTzxdkryUprhSlvSDN/p9JCO7U1ovo2+cKLnoLmexfS+9otpPmBuzD1DjwCu6lH3xvZ+HeBW7nm9D2pvvawHUFVXt0Pg/gO4Lsl8miFLx3QmCKOY1Z5z564YOy3pQ/Z43Ot6q+rPTd7Eb3vU/XMbz33aqKp7rRRYVXcmuYp7v182BobrniGeI3X/keTXNEPPul0+9iXcW5p5ah8Gng08uGt3Z8I7kjR0DyMcj6X5W7m2Ownn3u+tEf9CM0x1tNccYF3g9zRD0U4ATktyLU1Pz/eBY8uFB9RHJjCSlidL+rZ8PP/eTWgZ06o6NMmJwPNoxrTvDuyf5FtVtcd4mhhnHCOPX0kzzKaXXh+MJ8NIz8z9gccx+jLWva5ltOuYiAmvCJXkxTTDus6hmQPwe5phPCvRjP3vHH0Qlvy+WeKpluKYu5ewL133n6KJt5c/j2xU1XuTHEHzPnw6zXyMdyT576p61zjO91N69/xNhtGud0nPQ7fx/p0sjQm9v9peslNp5pv8D7CAZvjkYpok8hk94lua99dUvbdGthcA/28J9RcBVNWZbcL2bGDH9vZvwHuTbFdVNy1FnNIyM4GRtDwZ+c907R77xrOi0vU0H0Ye370jyUNo5qLM7yyvquuAw2km1q5EMyl2zySfGuMb8KuAxyZZqbMXJsn6NPNrOl3R3o+792QypFlF7IU0E7FfDByZZIv2mrtt1qNspCdhJLm6sr2/z/Pbcfx4E7ElfSh8BU3CsmPn8KAkm/ao+2tgF5ohW+eM89wjrqT5YPcvQPcQoZHr6dXTMJaR1/vuCfSWXQV8DvhcktWBk4F3tu/D60c5bBHNHIsH9aG3cyIenWTVuvfCC6vR9FJc1lHvKuBxSVbu7IVpFzp4LBNL8kd7f+0EPBx4dVX9X+eOJN1DXEd+V2lLJm4y/1a6XUHT+3bKGMPYAKiqW2kWUDgOIMm/A5+nmVO2xMVKpKniHBhJy41qVhj6I82KQ//8xjHNcrAvGsfxi2nmlGyZZJeu3e+m+Tfz+LbNB6RrWeU2ERn5INsriep0Is0woFd2lff6xvzbNPNtDuoYm/5PaZbBXW2M801IkifSfDj5Oc3qX3vQTPL9ajtXqNteSR7ZcfyqNJOF76aZDwLNhODfAa9KuwxzW3cV7plsfOI4Q7y1ve/1PN/dtvXPONv3w3t71P1Ge/+RXs9h5/uohxPa+//oer9tTjOX6vSqWtIwndFcQDNM6PXpsZRxmqWb126310rXcrbtMKKRYW0P6T6+o95imkUrnpRk9151JjqvZoo8iGZVtE7/3paf0FF2As0H89d01X1tW378BM55K6O/t6CrhyTJztx7/gs0wxIvAV6dpNeXIkt6b03m30q3o2hWy+vZA5NkvY7tXisWnt/ej/VvnDRl7IGRtLw5hGay/w+TnEDzbenraT4QbjOO4/+TZlL7CUm+QDNkanuaCe2ncs+ytI8FfpHk+LbtP9N8E/8Gmm/dT2PJ/ptmKMaX0iyZewnNylrb0kw4/qequibJG2h6en6V5Ks0KxTNAp5Ak5xtRrNy0lgekeTlo+w7s5338kDgaJreqJe3H3QvSPIumon576JZ1KDT5TTL7h7aHvdvNM/3h6rq9+113J1kf5oPkucmOayt+zLgKcBHquoKxufS9th/T/I3mp6E66vqFJqldl8CnJLkKJo5MC+iWeb6XqrqnCQfb6/pvCTfokmCN6YZEviktu37qKqfJPk2TXL3kCQncc8yynfQLHk8YVVVSV5BM6fqonZ42CVt/I+h6Q37D5pfid8ROCzJcTTf+N9KMwH8NcDZVfXr+57hXt4DPA34dnstZ9EsG70RzZLP59Gs2NVPVwIfaBPD82iu79U0vS+dk9b/G/hX4PNJtqJJBLek6Sn4dbt/vM4C9k3yIZpkcOTLjdNplzVOs3jHNTST9V9BMyzrn7//076Or6KZk3ROmt9Vuphm3swONMMDP9fr5JP8t9LtYJp/4z6R5Bk077ObaRYN2Im297Kt+6skZ9EsUHAtTS/0fjTvkaOR+qWfS6B58+bNW/eNe5bHffs46hZdy7zSfDHz3zRzRe6g+bbw+YxzGeW2fGOaoWDX0/xHfRXNsscP6KizDs2H+fk0H3Bvp0l2/gdYf5zXuiHNh+2baT6cfI/m90cW0mMJV5oPmsd3xHUtTQ/J2+haAngJz9eSbq9p6x1B84HtuT3aOIlmaeQnd71e+9B8YL+CprfoCuAto8SxA81qRze3r9EFI+fuqjePjqVle+x/bvv63sF9l55+LU2Sc0f7XjiM5hvj+7xn2vp70ixPewvNClyXta/lqu3+2fRYort9v72L5kPunTTDGE8AntBVr+fxY7wPN6L57Y2F7et9I80H+I8CG3S8Vw9tz39zG/uvaH67Y61xvg8fALyP5gP47e1z8CuaxRuePI7jR+LvtYzy3PH83bblR9IuzNZRtrB9H2xF80H7NpovC74KrNejjVk0K5RdQ/M+vYZmuNO6XfVGja/d/1CaIVM30fwt/PP1oRlu+KM2jlva+J7eK/62/uOAr9EkPiN/tycAW431XmcZ/1ZGe9/RvG/fDJzbPqe30fzNfh3YuaPeu2m+uLme5v39e5rfv9qq1/Pmzdt03UbWt5ekFU777ep7aT4MXjNWfd1Xkrk0SdSrqurIvgaj5U6aX6dfWFVz+xyKpBnEOTCSVmQPp/l29caxKkqSpJnBOTCSVjhJtgCeQzNe/tRqf/RQkiTNfPbASFoRjUyCPo3+T1CWJEkT4BwYSZIkSQPDHhhJkiRJA8M5MJqQddddt2bPnt3vMCRJkrScO++8826oqlnd5SYwmpDZs2czPDzc7zAkSZK0nEtyda9yExhJE7Loi1/rdwiSJGmazHrDy/sdwn04B0aSJEnSwDCBkSRJkjQwTGAkSZIkDQwTmAGR5GFJjk5yZZJLk/wgyX5JThql/uFJNpvuOCVJkqSp5CT+AZAkwPHAV6pqj7ZsDvD80Y6pqtdMT3SSJEnS9LEHZjDsCNxVVYeOFFTVfOA0YI0kxya5LMnX22SHJPOSDLXbtyb5cJILk5yVZL22/PlJzk5yQZKfjpRLkiRJM5UJzGDYHDhvlH1bAgcAmwGPAp7Wo84DgbOq6onAqcBr2/LTgadU1ZbA0cA7e52gHao2nGR40aJFS30RkiRJ0rIygRl851TVNVW1GJgPzO5R5+/AyFyZ8zrqPBI4OckC4B3A43udoKoOq6qhqhqaNes+P4YqSZIkTRsTmMFwCbD1KPvu7Ni+m97zmu6qqupR53PAIVX1BOB1wOqTEKskSZI0ZUxgBsMpwGpJRoZ+kWQbYIdlbHct4A/t9t7L2JYkSZI05UxgBkDbe7Ib8Kx2GeVLgAOBa5ex6QOBY5KcBtywjG1JkiRJU85llAdEVV0LvLTHri911Nm/Y3tux/YaHdvHAse22ycCJ05BuJIkSdKUsAdGkiRJ0sAwgZEkSZI0MBxCJmlCZr3h5f0OQZIkrcDsgZEkSZI0MExgJEmSJA0MExhJkiRJA8M5MJIm5E9f/O9+hyBJ0qjWe8M7+x2Cppg9MJIkSZIGhgmMJEmSpIFhAiNJkiRpYDgHZgZKcjewoKPoRVW1sE/hSJIkSTOGCczMdHtVzem1I0mAVNXi6Q1JkiRJ6j+HkA2AJLOT/CrJF4DzgQ2SfDHJcJJLkhzUUXdhkoOSnJ9kQZJN2/I1kvxfW3ZRkpe05TsnObOtf0ySNfpzlZIkSdLYTGBmpvsnmd/ejm/LHgccVVVbVtXVwHuqagjYAtghyRYdx99QVVsBXwTe3pa9D/hrVT2hqrYATkmyLvBe4Jlt/WHg/3UHk2S/NlkaXrRo0ZRcsCRJkjQeDiGbme41hCzJbODqqjqro85Lk+xH8xquD2wGXNTu+057fx7w4nb7mcAeIwdX1Z+T7Noed0YzMo1VgTO7g6mqw4DDAIaGhmoZr02SJElaaiYwg+O2kY0kG9P0rGzTJiJHAqt31L2zvb+be17jAN3JR4CfVNWeUxKxJEmSNMkcQjaYHkST0Pw1yXrAc8ZxzI+B/UceJHkIcBbwtCSPacsekOSxUxCvJEmSNClMYAZQVV0IXABcAhwBnDGOw/4LeEiSi5NcCOxYVYuAfYBvJrmIJqHZdGqiliRJkpadQ8hmoKpao+vxQmDzrrJ9Rjl2dsf2MDC33b4V2LtH/VOAbZYtYkmSJGl62AMjSZIkaWCYwEiSJEkaGA4hkzQh673hnf0OQZIkrcDsgZEkSZI0MExgJEmSJA0MExhJkiRJA8M5MJImZOFnX9TvECSpb2a/+YR+hyCt8OyBkSRJkjQwTGAkSZIkDQwTmOVAktlJLu4qOzDJ25M8JcnZSeYn+VWSA7vqHZzkD0l8L0iSJGnGcw7M8u8rwEur6sIkKwGPG9nRJi27Ab8Htgfm9SVCSZIkaZz81n3591DgOoCquruqLu3YtyNwMfBFYM8+xCZJkiRNiAnM8u8zwK+THJ/kdUlW79i3J/BN4Hhg1ySr9CVCSZIkaZxMYJYPNVp5VX0QGAJ+DPwb8COAJKsCzwVOqKqbgbOBnXs1kmS/JMNJhhctWjTpwUuSJEnjZQKzfLgReEhX2drADQBVdWVVfRHYCXhiknWAXYC1gAVJFgLbMcowsqo6rKqGqmpo1qxZU3QJkiRJ0thMYJYDVXUrcF2SnQCSrE2ToJye5HlJ0lbdBLgb+AtNsvKaqppdVbOBjYGdkzxguuOXJEmSxssEZvnxSuC9SeYDpwAHVdWVwCto5sDMB74K7AWsBjwb+P7IwVV1G3A68PzpDVuSJEkaP5dRXk60q4vt2KN8j1EOWbtH3RdPdlySJEnSZLIHRpIkSdLAMIGRJEmSNDBMYCRJkiQNDOfASJqQ2W8+od8hSJKkFZg9MJIkSZIGhgmMJEmSpIFhAiNJkiRpYDgHRtKEnP2/u/Y7BElaKk9+3Un9DkHSJLAHRpIkSdLAMIGRJEmSNDBMYGaoJHcnmZ/k4iTfS/LgSWz78CSbTVZ7kiRJ0nQxgZm5bq+qOVW1OXAT8MbJariqXlNVl05We5IkSdJ0MYEZDGcCjwBIMi/JULu9bpKF7fbjk5zT9tpclGSTJA9M8v0kF7Y9OS/r0cYXkwwnuSTJQf25PEmSJGl8XIVshkuyErAT8OUxqr4eOLiqvp5kVWAl4LnAtVX1vLattXoc956quqk9z8+SbFFVF03iJUiSJEmTxh6Ymev+SeYDNwJrAz8Zo/6ZwH8meRewUVXdDiwAnpnk40meXlV/7XHcS5OcD1wAPB64z9yYJPu1vTTDixYtWoZLkiRJkpaNCczMdXtVzQE2Alblnjkw/+Ce1231kcpV9Q3gBcDtwMlJnlFVlwNb0yQyH03y/s4TJNkYeDuwU1VtAXy/s82Otg+rqqGqGpo1a9YkXqIkSZI0MSYwM1zba/Jm4O1JVgEW0iQlALuP1EvyKOCqqvos8F1giyQPB/5WVV8DPgls1dX8g4DbgL8mWQ94zlReiyRJkrSsnAMzAKrqgiQXAnvQJCLfTvIK4JSOai8DXp7kLuCPwAeBbYBPJFkM3AW8oavdC5NcAFwCXAWcMeUXI0mSJC0DE5gZqqrW6Hr8/I6HW3Rsv7fd/1Hgo13NnNzeutue27G9zzKGKkmSJE0bh5BJkiRJGhgmMJIkSZIGhgmMJEmSpIHhHBhJE/Lk153U7xAkSdIKzB4YSZIkSQPDBEaSJEnSwHAImaQJ+eGXn9vvECTNUM/Z9wf9DkHSCsAeGEmSJEkDwwRGkiRJ0sAwgZEkSZI0MExgxinJe5JckuSiJPOTPHkp25mb5Kkdj49Msvs4jru1Y/u5Sa5IsuHSxCBJkiQNKifxj0OSbYFdga2q6s4k6wKrLmVzc4FbgV8uZSw7AZ8Ddq6q342jfoBU1eKlOZ8kSZI0k9gDMz7rAzdU1Z0AVXVDVV0LTUKR5IIkC5IckWS1tnxhm+iQZCjJvCSzgdcDb217cZ7etr99kl8muWpJvTFt/S8Bz6uqK9uy/5fk4vZ2QFs2O8mvknwBOB/YIMk7kpzb9iAd1NHmCUnOa3uX9pvMJ02SJEmabCYw4/NjmiTg8iRfSLIDQJLVgSOBl1XVE2h6tN4wWiNVtRA4FPhMVc2pqtPaXesD29H08nxslMNXA04EXlRVl7Xn3xp4FfBk4CnAa5Ns2dZ/HHBUVW3Zbm8CPAmYA2ydZPu23quramtgCHhzknXG/axIkiRJ08wEZhyq6lZga2A/YBHwrST70CQGv62qy9uqXwG279nIkp1QVYur6lJgvVHq3EUz7GzfjrLtgOOr6rY2xu8AI706V1fVWe32zu3tApoemU1pEhpokpYLgbOADTrK/ynJfkmGkwwvWrRoKS5PkiRJmhwmMONUVXdX1byq+gCwP/ASIEs45B/c8/yuPkbzd3Zsj9bmYuClwDZJ/nOMugC3dbX50bbXZ05VPaaqvpxkLvBMYNuqeiJNgnOfWKvqsKoaqqqhWbNmjXEpkiRJ0tQxgRmHJI9L0tkzMQe4GrgMmJ3kMW35K4BftNsLaXptoEl2RtwCrLk0cVTV32iGme2VZF/gVOBFSR6Q5IHAbsBpPQ49GXh1kjXa63lEkocCawF/rqq/JdmUZhiaJEmSNGOZwIzPGsBXklya5CJgM+DAqrqDZg7KMUkW0PSSHNoecxBwcJLTgLs72voesFvXJP5xq6qbgF2A99IM+ToSOAc4Gzi8qi7occyPgW8AZ7ZxHkuTRP0IWLm9pg/RDCOTJEmSZqxUVb9j0AAZGhqq4eHhfoehPvrhl5/b7xAkzVDP2fcH/Q5B0nIkyXlVNdRdbg+MJEmSpIFhAiNJkiRpYJjASJIkSRoYK/c7AEmDxTHukiSpn+yBkSRJkjQwTGAkSZIkDQyHkEmakK8f+ex+hyBpCu21z8n9DkGSlsgeGEmSJEkDwwRGkiRJ0sAwgZEkSZI0MExgZoAkD0tydJIrk1ya5AdJHjuF57t1qtqWJEmSppIJTJ8lCXA8MK+qHl1VmwH/CazX38gkSZKkmccEpv92BO6qqkNHCqpqPnBBkp8lOT/JgiQvBEgyO8mvknwpySVJfpzk/u2+1yY5N8mFSY5L8oC2fOMkZ7b7PjRyniRr9DqHJEmSNFOZwPTf5sB5PcrvAHarqq1okpxPtb01AJsAn6+qxwN/AV7Sln+nqrapqicCvwL2bcsPBr5YVdsAfxznOSRJkqQZxwRm5grwkSQXAT8FHsE9w8p+2/bSQJP8zG63N09yWpIFwF7A49vypwHfbLe/Os5z3FMp2S/JcJLhRYsWTca1SZIkSUvFBKb/LgG27lG+FzAL2Lqq5gB/AlZv993ZUe9u7vlB0iOB/avqCcBBHfUBaoLnuOfAqsOqaqiqhmbNmjW+q5IkSZKmgAlM/50CrJbktSMFSbYBNgKur6q7kuzYPh7LmsB1SVahSU5GnAHs0W53lq+1FOeQJEmS+sYEps+qqoDdgGe1yyhfAhwI/AAYSjJMk3RcNo7m3gecDfykq/5bgDcmOZcmaRnx9aU4hyRJktQ3K49dRVOtqq4FXtpj17ajHLJ5x7Gf7Nj+IvDFHu3/tqutj7XlNyzhHJIkSdKMYw+MJEmSpIFhAiNJkiRpYDiETNKE7LXPyf0OQZIkrcDsgZEkSZI0MExgJEmSJA0MExhJkiRJA8M5MJIm5JCvPbvfIUhLZf+XO39LkpYH9sBIkiRJGhgmMJIkSZIGhgmMJEmSpIFhAjMNkqyX5BtJrkpyXpIzk+zW77gkSZKkQWMCM8WSBDgBOLWqHlVVWwN7AI8c5/ErTWF4kiRJ0kAxgZl6zwD+XlWHjhRU1dVV9bkkKyX5RJJzk1yU5HUASeYm+XmSbwAL2se/SPLtJJcn+ViSvZKck2RBkke3xz0/ydlJLkjy0yTrteUHJjkiyby2F+jNbfmHkrxlJK4kHx7ZJ0mSJM1EJjBT7/HA+aPs2xf4a1VtA2wDvDbJxu2+JwHvqarN2sdPBN4CPAF4BfDYqnoScDjwprbO6cBTqmpL4GjgnR3n2hR4dtvuB5KsAnwZ2Bsgyf1oeoa+vmyXK0mSJE0dfwdmmiX5PLAd8HfgamCLJLu3u9cCNmn3nVNVv+049Nyquq5t40rgx235AmDHdvuRwLeSrA+sCnQe//2quhO4M8n1wHpVtTDJjUm2BNYDLqiqG3vEvB+wH8CGG264bE+AJEmStAzsgZl6lwBbjTyoqjcCOwGzgABvqqo57W3jqhpJTG7raufOju3FHY8Xc08i+jngkKp6AvA6YPVRjr+745jDgX2AVwFH9LqAqjqsqoaqamjWrFljXK4kSZI0dUxgpt4pwOpJ3tBR9oD2/mTgDe1wLpI8NskDl+FcawF/aLf3HucxxwO70Axh82eqJUmSNKM5hGyKVVUleRHwmSTvBBbR9K68CzgGmA2c365Wtgh40TKc7kDgmCR/AM4CNl5ydaiqvyf5OfCXqrp7Gc4tSZIkTblUVb9jUB+1k/fPB/61qq4Yq/7Q0FANDw9PfWCasQ752rP7HYK0VPZ/uZ3MkjRIkpxXVUPd5Q4hW4El2Qz4DfCz8SQvkiRJUr85hGwFVlWXAo/qdxySJEnSeJnASJoQh+FIkqR+cgiZJEmSpIFhAiNJkiRpYJjASJIkSRoYzoGRNCHv+/Yu/Q5BPXzopT/qdwiSJE0Le2AkSZIkDQwTGEmSJEkDwwRGkiRJ0sAwgRmHJJXkUx2P357kwDGOmZvkqR2Pj0yy+zLGsTDJusvSRkdbt05GO5IkSdJ0MoEZnzuBF08weZgLPHWsSuORhq+VJEmSVnh+KB6ffwCHAW/t3pFkVpLjkpzb3p6WZDbweuCtSeYneXpbffskv0xyVWdvTJJ3tMdelOSgtmx2kl8l+QJwPrBB13lPSHJekkuS7NdRfmuSDye5MMlZSdZryzdOcmZ7ng911F8/yaltnBd3xCpJkiTNOCYw4/d5YK8ka3WVHwx8pqq2AV4CHF5VC4FD2/I5VXVaW3d9YDtgV+BjAEl2BjYBngTMAbZOsn1b/3HAUVW1ZVVd3XXeV1fV1sAQ8OYk67TlDwTOqqonAqcCr+2I84ttnH/saOffgJOrag7wRGD+hJ4VSZIkaRr5OzDjVFU3JzkKeDNwe8euZwKbJRl5/KAka47SzAlVtRi4dKRnBNi5vV3QPl6DJqH5HXB1VZ01SltvTrJbu71Be8yNwN+Bk9ry84BntdtPo0mwAL4KfLzdPhc4IskqbXzzu0/U9vDsB7DhhhuOEo4kSZI09eyBmZj/Afal6eUYcT9g27anZU5VPaKqbhnl+Ds7ttNx/9GO4x9TVV9u993Wq5Ekc2kSp23bnpYLgNXb3XdVVbXbd3PvJLXoUlWnAtsDfwC+muSVPeocVlVDVTU0a9asUS5NkiRJmnomMBNQVTcB36ZJYkb8GNh/5EGSOe3mLcBoPTGdTgZenWSN9vhHJHnoGMesBfy5qv6WZFPgKeM4zxnAHu32Xh3xbgRcX1VfAr4MbDWOtiRJkqS+MIGZuE8BnauRvRkYaifgX0ozeR/ge8BuXZP476Oqfgx8AzgzyQLgWMZOfH4ErJzkIuBDwGjDzDq9BXhjknNpEqARc4H5SS6gGWJ28DjakiRJkvoi94w2ksY2NDRUw8PD/Q5DffS+b+/S7xDUw4de+qN+hyBJ0qRKcl5VDXWX2wMjSZIkaWCYwEiSJEkaGC6jLGlCHKokSZL6yR4YSZIkSQPDBEaSJEnSwDCBkSRJkjQwnAMjaUKe890X9DsEdfnhC77b7xAkSZo29sBIkiRJGhgmMJIkSZIGhgmMJEmSpIFhAjPgktza3s9O8m/jqD87ycVTH5kkSZI0+Uxglh+zgTETGEmSJGmQmcAsPz4GPD3J/CRvbXtaTktyfnt7avcB7f45HY/PSLLFdAYtSZIkTYQJzPLj3cBpVTWnqj4DXA88q6q2Al4GfLbHMYcD+wAkeSywWlVdNE3xSpIkSRNmArP8WgX4UpIFwDHAZj3qHAPsmmQV4NXAkb0aSrJfkuEkw4sWLZqqeCVJkqQxmcAsv94K/Al4IjAErNpdoar+BvwEeCHwUuAbvRqqqsOqaqiqhmbNmjV1EUuSJEljWLnfAWjS3AKs2fF4LeCaqlqcZG9gpVGOOxz4Hs3ws5umOEZJkiRpmdgDs/y4CPhHkguTvBX4ArB3krOAxwK39Tqoqs4Dbgb+b9oilSRJkpaSPTADrqrWaO/vAnbq2t25oth/tPUWApuPFCZ5OE0i++MpDVSSJEmaBPbArMCSvBI4G3hPVS3udzySJEnSWOyBWYFV1VHAUf2OQ5IkSRovExhJE/LDF3y33yFIkqQVmEPIJEmSJA0MExhJkiRJA8MERpIkSdLAcA6MpAl57vEf6HcIK6wf7HZQv0OQJKnv7IGRJEmSNDBMYCRJkiQNDBMYSZIkSQPDBGaAJLm13zFIkiRJ/WQCI0mSJGlgmMAMmCRrJPlZkvOTLEjywrZ8dpLLknwlyUVJjk3ygHbf+5Ocm+TiJIclSVs+L8nHk5yT5PIkT+/ntUmSJEljMYEZPHcAu1XVVsCOwKdGEhLgccBhVbUFcDPw7235IVW1TVVtDtwf2LWjvZWr6knAAYDr40qSJGlGM4EZPAE+kuQi4KfAI4D12n2/r6oz2u2vAdu12zsmOTvJAuAZwOM72vtOe38eMLvnCZP9kgwnGV60aNHkXYkkSZI0QSYwg2cvYBawdVXNAf4ErN7uq666lWR14AvA7lX1BOBLHfUB7mzv72aUHzatqsOqaqiqhmbNmjU5VyFJkiQtBROYwbMWcH1V3ZVkR2Cjjn0bJtm23d4TOJ17kpUbkqwB7D59oUqSJEmTywRmQCRZmaa35OvAUJJhmt6Yyzqq/QrYux1etjbwxar6C02vywLgBODcaQxbkiRJmlQ9hwxpRno8cGVV3QBs270zyWxgcVW9vntfVb0XeG+P8rkd2zcwyhwYSZIkaaawB2YAJHk98E16JCGSJEnSisQemAFQVYcCh45RZyGw+bQEJEmSJPWJCYykCfnBbgf1OwRJkrQCcwiZJEmSpIFhAiNJkiRpYJjASJIkSRoYzoGRNCHP+85n+x1C333/xW/udwiSJK2w7IGRJEmSNDBMYCRJkiQNDBMYSZIkSQPDBGYAJbl1gvXnJjmp3X5BkndPTWSSJEnS1HIS/wqmqr4LfLffcUiSJElLwx6YAdb2rMxLcmySy5J8PUnafbu0ZacDL+44Zp8kh7Tbz09ydpILkvw0yXp9uhRJkiRpXJY5gUmydpKtk6w2GQFpwrYEDgA2Ax4FPC3J6sCXgOcDTwceNsqxpwNPqaotgaOBd/aqlGS/JMNJhhctWjTJ4UuSJEnjN6EEJsl7k3y04/H2wELgHOCKJJtMbngah3Oq6pqqWgzMB2YDmwK/raorqqqAr41y7COBk5MsAN4BPL5Xpao6rKqGqmpo1qxZk34BkiRJ0nhNtAfm5cBVHY//G7gQeBHwJ+BDkxOWJuDOju27uWdeU43j2M8Bh1TVE4DXAatPcmySJEnSpJroJP5HAFcAJJkFbAPsVFXzkqwK+BPdM8NlwMZJHl1VVwJ7jlJvLeAP7fbe0xKZJEmStAwm2gNzN7Bqu709cAdwRvt4EbD2JMWlZVBVdwD7Ad9vJ/FfPUrVA4FjkpwG3DBN4UmSJElLbaI9MJcAL0/yS+DVwC+q6q523wbA9ZMZnHqrqjXa+3nAvI7y/Tu2f0QzF6b72COBI9vtE4ETpzJWSZIkaTJNNIH5IM0H3r2Au4Bnd+x7LnD+JMUlSZIkSfcxoQSmqk5O8i/AVsD8dn7FiFNpJvRLkiRJ0pRIs8quND5DQ0M1PDzc7zAkSZK0nEtyXlUNdZdPdAjZSGMPATahx7K7VXXq0rQpSZIkSWOZUALT/sL7EcBLgYxSbaVlDUqSJEmSepnoMsrvA+bS/GZIgP2B1wCnA1cCu05mcJIkSZLUaaJDyF5CsxLZ0cBXgbOr6nzg/5IcA+wC/HByQ5Q0k+x63JH9DqGvTnrJPv0OQZKkFdpEe2A2BC6pqrtpllF+YMe+I4CXTVZgkiRJktRtognMjcAa7fbvgSd27FsXuP9kBCVJkiRJvUx0CNlZwJY0w8SOAz6UZE3gH8DbaObCSJIkSdKUmGgC83GaYWQA/wU8hmZOzEo0yc2/T15oy68kdwMLaBZCuBvYv6p+OcYxt1bVGmPUORz4dFVdOmnBSpIkSTPIhBKYqhoGhtvtW4CXJFkNWK2qbp6C+JZXt1fVHIAkzwY+CuywrI1W1WuWtQ1JkiRpJpvQHJgk70/y8M6yqrqzqm5Osn6S909ueCuEBwF/HnmQ5B1Jzk1yUZKDuisnuV+SLyS5JMlJSX6QZPd237wkQ+32rR3H7J7kyHb7yCRfTPLzJFcl2SHJEUl+NVJHkiRJmqkmOon/A8AjR9n38Ha/xnb/JPOTXAYcDnwIIMnOwCbAk4A5wNZJtu869sXAbOAJNL/Bs+1SnP8hwDOAtwLfAz4DPB54QpI53ZWT7JdkOMnwokWLluJ0kiRJ0uSYaAKTJex7CHDnMsSyIrm9quZU1aY0v51zVJIAO7e3C4DzgU1pEppO2wHHVNXiqvoj8POlOP/3qqpo5uH8qaoWVNVi4BKa5OhequqwqhqqqqFZs2YtxekkSZKkyTHmHJgkc2m+rR/xuiS7dlW7P/A8mg/AmoCqOjPJusAsmgTxo1X1v0s4ZElJ5L2a7thevWvfSKK5mHsnnYuZ+MIOkiRJ0rQZz4fVHYD3ttsFvKpHnb8DlwJvnqS4VhhJNqVZxe1G4GSapam/XlW3JnkEcFdVXd9xyOnA3km+QpP0zAW+0aPpPyX5F+DXwG7ALVN4GZIkSdK0GDOBqaqDgIMAkiwGnlJV50x1YMu5+yeZ324H2Luq7gZ+3CYdZzYjyrgVeDnQmcAcB+wEXAxcDpwN/LXHOd4NnETzg6MXc88PkEqSJEkDa6LLKE90zox6qKqVlrDvYODgHuVrtPeLk7y97aFZBziHZi4LVTW3o/6xwLE92tmnY3shsHmvfZIkSdJMNKEEJsmGY9Wpqt8tfTgap5OSPBhYFfhQO5lfkiRJWu5NdML2Qu49ObyXUXsXNDk6e1okSZKkFclEE5hXc98EZh2aFcgeRft7JpKWXye9ZJ9+hyBJklZgE50Dc+Qouz6d5Ks0SYwkSZIkTYnJnJT/NZoeGkmSJEmaEpOZwDyU+/5goiRJkiRNmomuQrZ9j+JVaZbi/Q/gtMkIStLMteuxx/Q7hL44afd/7XcIkiSJiU/in8d9J/Gnvf8F8IZlDUiSJEmSRjPRBGbHHmV3AFcDfwFeR48fYZQkSZKkyTDRBOYS4Maq+mcvTJL7A/8OvJ1mHowJjCRJkqQpMeYk/iSrJTk4ya3An4Abk7yh3fdy4CrgE8DvgF2mMtjxSjI7ycVdZQcmefsYxw0l+Wy7PTfJU5fi3AuTrLuk8iRbJ/ltki2TvCDJuyd6nlHOPTfJSZPRliRJkjQTjacH5v3Am4CfAucDGwMHJ9kMeCNwObBfVX1vyqKcJlU1DAy3D+cCtwK/nMxzJNkCOBZ4WVVdAFwAfHcyzyFJkiQtr8aTwLwM+EJV7T9SkOTVwOHAT4DnV9Xfpyi+KZFkHnA2zZyeBwP7VtVpSebSDIXbH3g9cHfby/Qm4DLgUGDDtpkDquqMJOsA3wRmAedwz6IGvfwL8BXgFVV1ThvLPsBQVe2f5EjgZmAIeBjwzqo6Nsn9gEOAHYDf0vScHdHu2wX4H+AGmgRz5BrXBo6g+XHRv9EkmRclOZAmCV0feCzw/4CnAM8B/kDzet417idTkiRJmkbj+R2YDYDju8q+095/etCSlw4rV9WTgAOAD3TuqKqFNMnKZ6pqTlWdRjO35zNVtQ3wEpoEjvbY06tqS5qelA0Z3YnA/lV1+hLqrA9sB+wKfKwtezEwG3gC8BpgW4AkqwNfAp4PPJ0m6RlxEHBBVW0B/CdwVMe+RwPPA15I8wOkP6+qJwC3t+X3kmS/JMNJhhctWrSE0CVJkqSpNZ4EZhXglq6ykccz9dNs91LPvcpHkrDzaJKDsTwTOCTJfJpE5UFJ1gS2p0kCqKrvA39eQhs/BV6TZKUl1DmhqhZX1aXAem3ZdsAxbfkfgZ+35ZsCv62qK9qFFb7W0c52wFfbuE4B1kmyVrvvh20vywJgJeBHbfkCejwXVXVYVQ1V1dCsWbOWELokSZI0tca7Ctkjkjyq4/FKHeV/6axYVVdNRmDL6EbgIV1la9MMvxpxZ3t/N+N7Hu4HbFtVt3cWJoHRE6Zu+9P07HyBZsnpXu7s2E7XfS+jnbvXMSN17wSoqsVJ7upYVW4xE1+ZTpIkSZo24+mBgWbS+RUdt8va8hO6yq+Y5PiWSlXdClyXZCf453yQXYAlDd3qdguwZsfjH9MkILRtzmk3TwX2asuew30Tp06LgT2BxyX54ARiOR14SZL7JVmPZoEBaF6HjZM8un28Z8cxnXHNBW6oqpsncE5JkiRpxhnPt+2vmvIopsYrgc8n+VT7+KCqunICx38PODbJC2km8b+5be8imuftVJqJ/gcB30xyPvALmuWkR1VVd7Zt/iLJn4DbxhHLccBOwMU0q76dDfy1qu5Ish/w/SQ30CQ6m7fHHAj8Xxvv34C9x33lkiRJ0gyVjt+k1AyWZI2qurVd9ewc4GntfJhpNTQ0VMPDw2NX1HJr12OP6XcIfXHS7v/a7xAkSVqhJDmvqoa6y53vMDhOSvJgYFXgQ/1IXiRJkqR+M4EZEFU1t98xSJIkSf1mAiNpQhxKJUmS+mm8q5BJkiRJUt+ZwEiSJEkaGCYwkiRJkgaGc2AkTcgLj/1Rv0OYdCfuvku/Q5AkSeNkD4wkSZKkgWECI0mSJGlgmMBMUJL3JLkkyUVJ5id58jiO+WCSZ7bbByR5wCTFcmCSt09SW0cm2X0y2pIkSZKminNgJiDJtsCuwFZVdWeSdYFVxzquqt7f8fAA4GvA35YxFl87SZIkrXDsgZmY9YEbqupOgKq6AXhkku8AJHlhktuTrJpk9SRXteVHJtk9yZuBhwM/T/LzJC9oe3HmJ/l1kt+29bdO8osk5yU5Ocn6bfm8JB9J8gvgLZ2BJXltknOTXJjkuJFenvbcn03yyyRXjfSypHFIkkuTfB946HQ8gZIkSdKyMIGZmB8DGyS5PMkXkuwAnA9s2e5/OnAxsA3wZODszoOr6rPAtcCOVbVjVX23quZU1RzgQuCTSVYBPgfsXlVbA0cAH+5o5sFVtUNVfaortu9U1TZV9UTgV8C+HfvWB7aj6T36WFu2G/A44AnAa4GnLt1TIkmSJE0fhyFNQFXdmmRrmkRlR+BbwLuB3yT5F+BJwKeB7YGVgNPG026SdwK3V9Xnk2wObA78JAltO9d1VP/WKM1snuS/gAcDawAnd+w7oaoWA5cmWa8t2x74ZlXdDVyb5JQlxLcfsB/AhhtuOJ5LkiRJkqaECcwEtR/45wHzkiwA9qZJVJ4D3AX8FDiSJvEYc4J9kp2Af6VJKAACXFJV245yyG2jlB8JvKiqLkyyDzC3Y9+dnafsvJyx4gOoqsOAwwCGhobGdYwkSZI0FRxCNgFJHpdkk46iOcDVwKk0k/PPrKpFwDrApsAlPZq5BVizbW8j4AvAS6vq9nb/r4FZ7YIBJFklyePHEd6awHXtELS9xlH/VGCPJCu1c2x2HMcxkiRJUl/ZAzMxawCfS/Jg4B/Ab2iGVt0GrEeTFABcBFxfVb16Kw4DfpjkOpqenHWA49vhYtdW1XPbifafTbIWzWv0P/ROhjq9j2bOzdXAAtokaQmOB57R1r0c+MUY9SVJkqS+S+/P2FJvQ0NDNTw83O8w1EcvPPZH/Q5h0p24+y79DkGSJHVJcl5VDXWXO4RMkiRJ0sAwgZEkSZI0MExgJEmSJA0MJ/FLmhDni0iSpH6yB0aSJEnSwDCBkSRJkjQwTGAkSZIkDQznwEiakBcfd2a/Q5iQ77xk236HIEmSJpE9MJIkSZIGhgmMJEmSpIFhAjMgktydZH6SC5Ocn+Spk9Tu4Uk2a7cXJll3MtqVJEmSpoJzYAbH7VU1ByDJs4GPAjt0VkiyUlXdPZFGq+o1kxahJEmSNMXsgRlMDwL+DJBkbpKfJ/kGsKAtOyHJeUkuSbJfW/aCtgdnfpJfJ/ltWz4vyVC/LkSSJEmaCHtgBsf9k8wHVgfWB57Rse9JwOZV9dv28aur6qYk9wfOTXJcVX0X+C5Akm8Dv5i+0CVJkqTJYQ/M4Li9quZU1abALsBRSdLuO6cjeQF4c5ILgbOADYBNRnYkeWfb1ufHe+Ik+yUZTjK8aNGiZb8SSZIkaSmZwAygqjoTWBeY1RbdNrIvyVzgmcC2VfVE4AKaXhuS7AT8K/D6CZ7vsKoaqqqhWbNmjX2AJEmSNEUcQjaAkmwKrATc2GP3WsCfq+pvbb2ntMdsBHwB2KWqbp+2YCVJkqRJZAIzOEbmwAAE2Luq7r5nFNk//Qh4fZKLgF/TDCMD2AdYBzi+PebaqnruVActSZIkTSYTmAFRVSuNUj4PmNfx+E7gOT2qzgMO6nH83I7t2csUpCRJkjTFnAMjSZIkaWCYwEiSJEkaGCYwkiRJkgaGc2AkTch3XrJtv0OQJEkrMHtgJEmSJA0MExhJkiRJA8MhZJIm5GXfuWpS2vnWix81Ke1IkqQViz0wkiRJkgaGCYwkSZKkgWECI0mSJGlgmMBMoyS7Jakkmy7l8S9KstlSHLdPkkPa7dcneeXSnF+SJEnqNxOY6bUncDqwx1Ie/yKgZwKTZFwLMlTVoVV11FKeX5IkSeorE5hpkmQN4GnAvrQJTJK5SU7qqHNIkn3a7Y8luTTJRUk+meSpwAuATySZn+TRSeYl+UiSXwBvSfL8JGcnuSDJT5Os1yOOA5O8vd1+bZJzk1yY5LgkD5jyJ0KSJElaBi6jPH1eBPyoqi5PclOSrUarmGRtYDdg06qqJA+uqr8k+S5wUlUd29YDeHBV7dA+fgjwlPaY1wDvBN62hJi+U1Vfao/9L5rk6nPLfKWSJEnSFLEHZvrsCRzdbh/dPh7NzcAdwOFJXgz8bQl1v9Wx/Ujg5CQLgHcAjx8jps2TnNbW32u0+kn2SzKcZHjRokVjNClJkiRNHROYaZBkHeAZNAnJQprk4mXA3dz7NVgdoKr+ATwJOI6252YJzd/Wsf054JCqegLwupH2luBIYP+2/kGj1a+qw6pqqKqGZs2aNUaTkiRJ0tQxgZkeuwNHVdVGVTW7qjYAftvu2yzJaknWAnaCf86XWauqfgAcAMxp694CrLmE86wF/KHd3nscca0JXJdkFZoeGEmSJGlGcw7M9NgT+FhX2XHAvwHfBi4CrgAuaPetCZyYZHUgwFvb8qOBLyV5M01S1O1A4JgkfwDOAjYeI673AWcDVwMLWHJyJEmSJPVdqqrfMWiADA0N1fDwcL/DUB+97DtXTUo733rxoyalHUmStHxKcl5VDXWXO4RMkiRJ0sAwgZEkSZI0MExgJEmSJA0MJ/FLmhDnrkiSpH6yB0aSJEnSwDCBkSRJkjQwHEImaUIOPv6P4677lt0eNoWRSJKkFZE9MJIkSZIGhgmMJEmSpIFhAiNJkiRpYJjADJAk70lySZKLksxP8uSlaOMFSd49FfFJkiRJU81J/AMiybbArsBWVXVnknWBVSfaTlV9F/juZMcnSZIkTQd7YAbH+sANVXUnQFXdUFXXJlmY5ONJzmlvjwFI8vwkZye5IMlPk6zXlu+T5JB2+8gkn03yyyRXJdm9b1cnSZIkjYMJzOD4MbBBksuTfCHJDh37bq6qJwGHAP/Tlp0OPKWqtgSOBt45SrvrA9vR9O58bEoilyRJkiaJQ8gGRFXdmmRr4OnAjsC3OuayfLPj/jPt9iPbOuvTDDX77ShNn1BVi4FLR3ppuiXZD9gPYMMNN1zma5EkSZKWlj0wA6Sq7q6qeVX1AWB/4CUjuzqrtfefAw6pqicArwNWH6XZOzu2M8p5D6uqoaoamjVr1tJfgCRJkrSMTGAGRJLHJdmko2gOcHW7/bKO+zPb7bWAP7Tbe095gJIkSdI0cAjZ4FgD+FySBwP/AH5DM6xrV2C1JGfTJKR7tvUPBI5J8gfgLGDj6Q5YkiRJmmwmMAOiqs4DntpdngTg81V1UFf9E4ETe7RzJHBku71P1741JiteSZIkaSo4hEySJEnSwLAHZsBV1ex+xyBJkiRNFxMYSRPylt0e1u8QJEnSCswhZJIkSZIGhgmMJEmSpIFhAiNJkiRpYJjASJIkSRoYJjCSJEmSBoYJjCRJkqSBYQIjSZIkaWCYwMwwSXZLUkk2XcrjX5RksyXsf32SVy59hJIkSVL/mMDMPHsCpwN7LOXxLwJ6JjBJVq6qQ6vqqKVsW5IkSeorE5gZJMkawNOAfWkTmCRzk5zUUeeQJPu02x9LcmmSi5J8MslTgRcAn0gyP8mjk8xL8pEkvwDekuTAJG9vj39tknOTXJjkuCQPmOZLliRJkiZk5X4HoHt5EfCjqro8yU1JthqtYpK1gd2ATauqkjy4qv6S5LvASVV1bFsP4MFVtUP7+MCOZr5TVV9qy/+LJnH63BRclyRJkjQp7IGZWfYEjm63j24fj+Zm4A7g8CQvBv62hLrfGqV88ySnJVkA7AU8vlelJPslGU4yvGjRoiVegCRJkjSV7IGZIZKsAzyDJqkoYCWggO9y70RzdYCq+keSJwE70Qw32789vpfbRik/EnhRVV3YDkub26tSVR0GHAYwNDRU474oSZIkaZLZAzNz7A4cVVUbVdXsqtoA+G27b7MkqyVZiyZhGZkvs1ZV/QA4AJjT1r0FWHOc51wTuC7JKjQ9MJIkSdKMZg/MzLEn8LGusuOAfwO+DVwEXAFc0O5bEzgxyepAgLe25UcDX0ryZpqkaEneB5wNXA0sYPyJjyRJktQXqXJEkMZvaGiohoeH+x2GJEmSlnNJzquqoe5yh5BJkiRJGhgmMJIkSZIGhgmMJEmSpIFhAiNJkiRpYJjASJIkSRoYJjCSJEmSBoa/AyPpn878yqIx62y796xpiESSJKk3e2AkSZIkDQwTGEmSJEkDwwRGkiRJ0sCYtgQmyewkF3eVHZjk7WMcN5Tks+323CRPXYpzL0yy7ij7tkxSSZ490XbHarujzj5JFiWZ33HbbALneH2SV04wrqV6riRJkqSZbMZP4q+qYWC4fTgXuBX45SSeYk/g9Pb+5O6dSQKkqhYv43m+VVX7L82BVXVor/IkK1fVP0Y5bC6T/1xJkiRJfTVjhpAlmZfk40nOSXJ5kqe35XOTnJRkNvB64K1tD8bTk8xKclySc9vb09pj1kny4yQXJPlfIKOcM8DuwD7AzklWb8tnJ/lVki8A5wMbJPlikuEklyQ5qKupd7Rxn5PkMRO45rlJfpHk2+01fyzJXm07C5I8uq33z56q9nn6SJJfAG9J8vwkZ7fX+tMk603wudqho1fogiRrjjd+SZIkabrNtB6YlavqSUmeC3wAeObIjqpamORQ4Naq+iRAkm8An6mq05NsSNOD8i/tsadX1QeTPA/Yb5TzPQ34bVVdmWQe8FzgO+2+xwGvqqp/b8/1nqq6KclKwM+SbFFVF7V1b27jfiXwP8CuPc71siTbdTzetr1/YhvzTcBVwOFtW28B3gQc0KOtB1fVDm1cDwGeUlWV5DXAO6vqbRN4rt4OvLGqzkiyBnDHKM+VJEmS1HfTmcDUOMpHkofzgNnjaPOZwGZNRwoAD2p7ELYHXgxQVd9P8udRjt8TOLrdPhp4RUcMV1fVWR11X5pkP5rnbH1gM2Akgflmx/1nRjnXfYaQtXGfW1XXtY+vBH7c7l4A7DhaWx3bjwS+lWR9YFXgt6McM9pzdQbw6SRfB75TVdd0H9he934AG2644SjNS5IkSVNvOhOYG4GHdJWtzb0/cN/Z3t/N+GK7H7BtVd3eWdh+SB8tYRqpsxLwEuAFSd5DM8xsnY4hVLd11N2Ypqdim6r6c5IjgdU7mqtRtsfjzo7txR2PFzP6c3Bbx/bngE9X1XeTzAUOHOWYns8V8LEk36fpfToryTOr6rLOClV1GHAYwNDQ0ESvT5IkSZo00zYHpqpuBa5LshNAkrWBXWgm0I/XLUDnHI0fA//s1Ugyp908FdirLXsO902coOmRuLCqNqiq2VW1EXAc8KIedR9EkzT8Ncl6wHO69r+s4/7MCVzPZFgL+EO7vXdH+bieqySPrqoFVfVxmsUSNp3SaCVJkqRlMN2T+F8JvDfJfOAU4KCqunICx38P2G1kYjrwZmAoyUVJLqWZuA5wELB9kvOBnYHf9WhrT+D4rrLjgH/rrlhVFwIXAJcAR9AMu+q0WpKzgbcAbx0l9pfl3ssoT9YSxwcCxyQ5Dbiho3y8z9UBSS5OciFwO/DDSYpLkiRJmnSpckSQxm9oaKiGh4fHrqiBdOZXFo1ZZ9u9Z01DJJIkaUWX5LyqGuounzHLKEuSJEnSWExgJEmSJA2MmfY7MJL6yOFhkiRpprMHRpIkSdLAMIGRJEmSNDBMYCRJkiQNDOfASCuw33zuTxM+5jFvWm8KIpEkSRofe2AkSZIkDQwTGEmSJEkDwwRGkiRJ0sAwgZlmSeYleXZX2QFJrkry7jGOnZvkqVMboSRJkjRzmcBMv28Ce3SV7QHsXVUfG+PYuYAJjCRJklZYJjDT71hg1ySrASSZDTwceEySQ9qyWUmOS3Jue3taW+/1wFuTzE/y9CRHJvlskl+2PTi7t8evkeRnSc5PsiDJC0fOleSyJIcnuTjJ15M8M8kZSa5I8qQ+PB+SJEnSuJnATLOquhE4B9ilLdoD+BZQHdUOBj5TVdsALwEOr6qFwKFt+ZyqOq2tuz6wHbArMNKDcwewW1VtBewIfCpJ2n2PadvfAtgU+Lf2+LcD/zm5VytJkiRNLn8Hpj9GhpGd2N6/miahGPFMYLN7cg4elGTNUdo6oaoWA5cmGfmBjgAfSbI9sBh4BDCy77dVtQAgySXAz6qqkiwAZvc6QZL9gP0ANtxwwwleqiRJkjR57IHpjxOAnZJsBdy/qs7v2n8/YNu2p2VOVT2iqm4Zpa07O7ZHMp69gFnA1lU1B/gTsHqP+os7Hi9mlIS2qg6rqqGqGpo1a9bYVydJkiRNEROYPqiqW4F5wBE0vTHdfgzsP/IgyZx28xZgtJ6YTmsB11fVXUl2BDZalnglSZKkmcIEpn++CTwROLrHvjcDQ0kuSnIpzeR9gO8Bu41M4l9C219vjx+m6Y25bBLjliRJkvomVTV2Lak1NDRUw8PD/Q5Dk+Q3n/vThI95zJvWG7uSJEnSMkpyXlUNdZfbAyNJkiRpYJjASJIkSRoYLqMsrcAcDiZJkgaNPTCSJEmSBoYJjCRJkqSBYQIjSZIkaWA4B0YrrD9+6op+hzCQHva2TfodgiRJWoHZAyNJkiRpYJjASJIkSRoYJjCSJEmSBoYJzAySpJJ8tePxykkWJTlpKdt7fZJXTl6EkiRJUn85iX9muQ3YPMn9q+p24FnAH5a2sao6dNIikyRJkmYAe2Bmnh8Cz2u39wS+ObIjyQOTHJHk3CQXJHlhW/7ZJO9vt5+d5NQk90tyYJK3t+WPSfLTJBcmOT/Jo9P4RJKLkyxI8rJpvlZJkiRpQkxgZp6jgT2SrA5sAZzdse89wClVtQ2wI/CJJA8E3g28LMmOwGeBV1XV4q52vw58vqqeCDwVuA54MTAHeCLwzLa99afsyiRJkqRlZAIzw1TVRcBsmt6XH3Tt3hl4d5L5wDxgdWDDqvob8FrgJ8AhVXVl50FJ1gQeUVXHt+e4oz1mO+CbVXV3Vf0J+AWwTXdMSfZLMpxkeNGiRZN2rZIkSdJEOQdmZvou8ElgLrBOR3mAl1TVr3sc8wTgRuDhPfZllPOMVn4vVXUYcBjA0NBQjecYSZIkaSrYAzMzHQF8sKoWdJWfDLwpSQCSbNnebwS8DdgSeE6SJ3ceVFU3A9ckeVFbf7UkDwBOpRl6tlKSWcD2wDlTd1mSJEnSsjGBmYGq6pqqOrjHrg8BqwAXJbkY+FCbzHwZeHtVXQvsCxzezqHp9ArgzUkuAn4JPAw4HrgIuBA4BXhnVf1xSi5KkiRJmgSpckSQxm9oaKiGh4f7Hcak+OOnruh3CAPpYW/bpN8hSJKkFUCS86pqqLvcHhhJkiRJA8MERpIkSdLAcBUyrbAcCiVJkjR47IGRJEmSNDBMYCRJkiQNDBMYSZIkSQPDOTBaLv3p4LP6HcJya723PKXfIUiSpBWYPTCSJEmSBoYJjCRJkqSBYQIjSZIkaWCYwEyTJJXkqx2PV06yKMlJYxw3d6w6E4zj4UmOnaz2JEmSpOlkAjN9bgM2T3L/9vGzgD9MdxBVdW1V7T7d55UkSZImgwnM9Poh8Lx2e0/gmyM7kjwpyS+TXNDeP6774NHqJDktyZyOemck2SLJDknmt7cLkqyZZHaSi9t6s9tjz29vT53Ki5ckSZKWlQnM9Doa2CPJ6sAWwNkd+y4Dtq+qLYH3Ax/pcfxodQ4H9gFI8lhgtaq6CHg78MaqmgM8Hbi9q73rgWdV1VbAy4DP9go6yX5JhpMML1q0aGJXLEmSJE0ifwdmGlXVRUlm0/S+/KBr91rAV5JsAhSwSo8mRqtzDPC+JO8AXg0c2ZafAXw6ydeB71TVNUk621sFOKTtvbkbeOwocR8GHAYwNDRU471eSZIkabLZAzP9vgt8ko7hY60PAT+vqs2B5wOr9zi2Z52q+hvwE+CFwEuBb7TlHwNeA9wfOCvJpl3tvRX4E/BEYAhYdVkvTpIkSZpK9sBMvyOAv1bVgiRzO8rX4p5J/fuMcuyS6hwOfA84rapuAkjy6KpaACxIsi2wKTC/q71rqmpxkr2BlZbieiRJkqRpYw/MNKuqa6rq4B67/hv4aJIzGD2RGLVOVZ0H3Az8X0fxAUkuTnIhzfyXH3a19wVg7yRn0Qwfu23CFyRJkiRNo1Q5pWF5kOThwDxg06paPFXnGRoaquHh4alqftL86eCz+h3Ccmu9tzyl3yFIkqQVQJLzqmqou9wemOVAklfSrGj2nqlMXiRJkqR+cw7McqCqjgKO6ncckiRJ0lQzgdFyyWFOkiRJyyeHkEmSJEkaGCYwkiRJkgaGCYwkSZKkgeEcGA2M6w/p/hkb9cND939Ov0OQJEkrMHtgJEmSJA0MExhJkiRJA8MERpIkSdLAMIGZZEnek+SSJBclmZ/kyUkOT7JZv2OTJEmSBp2T+CdRkm2BXYGtqurOJOsCq1bVa/oc2n0kWamq7u53HJIkSdJE2AMzudYHbqiqOwGq6oaqujbJvCRDAEluTfLhJBcmOSvJem35o9vH5yb5YJJb2/I1kvwsyflJFiR5YVs+O8llSb7S9vYcm+QB7b6dklzQ1j8iyWpt+cIk709yOvCvSXZOcmbb9jFJ1pj+p0ySJEkaPxOYyfVjYIMklyf5QpIdetR5IHBWVT0ROBV4bVt+MHBwVW0DXNtR/w5gt6raCtgR+FSStPseBxxWVVsANwP/nmR14EjgZVX1BJpetjd0tldV2wE/Bd4LPLNtexj4f70uKsl+SYaTDC9atGhCT4gkSZI0mUxgJlFV3QpsDewHLAK+lWSfrmp/B05qt88DZrfb2wLHtNvf6Kgf4CNJLqJJOh4BrNfu+31VndFufw3Yjiap+W1VXd6WfwXYvqO9b7X3TwE2A85IMh/YG9holOs6rKqGqmpo1qxZo12+JEmSNOWcAzPJ2nkl84B5SRbQJAad7qqqarfvZuzXYC9gFrB1Vd2VZCGw+sjpuk9Pk/AsyW3tfYCfVNWeY9SXJEmSZgx7YCZRkscl2aSjaA5w9TgPPwt4Sbu9R0f5WsD1bfKyI/fuJdmwXTgAYE/gdOAyYHaSx7TlrwB+Mcr5njZSL8kDkjx2nLFKkiRJfWECM7nWAL6S5NJ2yNdmwIHjPPYA4P8lOYdmMYC/tuVfB4aSDNP0xlzWccyvgL3bc60NfLGq7gBeBRzT9gAtBg7tPllVLQL2Ab7ZHn8WsOn4L1WSJEmafg4hm0RVdR7w1B675nbUWaNj+1jg2PbhH4CnVFUl2YNmUj1VdQPN/Jh7STIbWFxVr+8Rx8+ALXuUz+56fAqwzRiXJUmSJM0YJjAzx9bAIe0KY38BXt3fcCRJkqSZxwRmhqiq04AnTqD+QmDzKQtIkiRJmoFMYDQwHrr/c/odgiRJkvrMSfySJEmSBkbu+UkSaWxJFtF7aeh1gRumORz1h6/1isPXesXha73i8LVecSwPr/VGVXWfX1E3gdGkSDJcVUP9jkNTz9d6xeFrveLwtV5x+FqvOJbn19ohZJIkSZIGhgmMJEmSpIFhAqPJcli/A9C08bVecfharzh8rVccvtYrjuX2tXYOjCRJkqSBYQ+MJEmSpIFhAqOlkmTtJD9JckV7/5BR6i1MsiDJ/CTD0x2nll6SXZL8Oslvkry7x/4k+Wy7/6IkW/UjTi27cbzWc5P8tf07np/k/f2IU8smyRFJrk9y8Sj7/ZteTozjtfZvejmRZIMkP0/yqySXJHlLjzrL3d+2CYyW1ruBn1XVJsDP2sej2bGq5iyvS/ktj5KsBHweeA6wGbBnks26qj0H2KS97Qd8cVqD1KQY52sNcFr7dzynqj44rUFqshwJ7LKE/f5NLz+OZMmvNfg3vbz4B/C2qvoX4CnAG1eE/69NYLS0Xgh8pd3+CvCi/oWiKfAk4DdVdVVV/R04muY17/RC4KhqnAU8OMn60x2oltl4XmstB6rqVOCmJVTxb3o5MY7XWsuJqrquqs5vt28BfgU8oqvacve3bQKjpbVeVV0HzR8P8NBR6hXw4yTnJdlv2qLTsnoE8PuOx9dw338Qx1NHM994X8dtk1yY5IdJHj89oWma+Te9YvFvejmTZDawJXB2167l7m975X4HoJkryU+Bh/XY9Z4JNPO0qro2yUOBnyS5rP1mSDNbepR1L1k4njqa+cbzOp4PbFRVtyZ5LnACzVAELV/8m15x+De9nEmyBnAccEBV3dy9u8chA/23bQ+MRlVVz6yqzXvcTgT+NNL92N5fP0ob17b31wPH0wxX0cx3DbBBx+NHAtcuRR3NfGO+jlV1c1Xd2m7/AFglybrTF6KmiX/TKwj/ppcvSVahSV6+XlXf6VFlufvbNoHR0vousHe7vTdwYneFJA9MsubINrAz0HNFFM045wKbJNk4yarAHjSveafvAq9sVzd5CvDXkWGFGihjvtZJHpYk7faTaP7vuHHaI9VU8296BeHf9PKjfR2/DPyqqj49SrXl7m/bIWRaWh8Dvp1kX+B3wL8CJHk4cHhVPRdYDzi+/TdyZeAbVfWjPsWrCaiqfyTZHzgZWAk4oqouSfL6dv+hwA+A5wK/Af4GvKpf8WrpjfO13h14Q5J/ALcDe5S/gjxwknwTmAusm+Qa4APAKuDf9PJmHK+1f9PLj6cBrwAWJJnflv0nsCEsv3/b8f0qSZIkaVA4hEySJEnSwDCBkSRJkjQwTGAkSZIkDQwTGEmSJEkDwwRGkiRJ0oQlOSLJ9UnG/JmMJNsnOT/JP5Ls3rVv7yRXtLe9R2tjhAmMJM0wSfZJUqPcntnWmds+nrsU7R+YZFqXoGx/F+q6JC+Z4HELkxzZVfb8JAuS3NE+Bw+ezFiXN93PYcf7a/YUnnN2e459OsqOTLJwSXVmqiRvTXJREj83Sfd2JLDLOOv+DtgH+EZnYZK1aZb6fjLND55/IMlDltSQvwMjSTPXv9L8gnKnSyeh3cOB6f5NprcBNwC9fiV6SXYDbh55kGRl4OvAL4E3An8HbpmkGJdX93oOp8l1wLbAldN83qlyKPAumh9u/r8+xyLNGFV1aveXIUkeDXwemEXzuzOvrarLqmphu39xVzPPBn5SVTe1+39CkxR9c7TzmsBI0sw1v6p+M9mNVtU13DcxmjJJVgXeBBw40R/Lq6oLuooeAawJfLuqTh3jvKtV1Z0TCnY51OM5nI5z3gmcNd3nnSpVdXuSo4C3YwIjjeUw4PVVdUWSJwNfAJ6xhPqPAH7f8fiatmxUdoVK0nKi13CrtrySHNjx+D5DyJI8KMkhSa5NcmeSX7fDZtJRZ40kn0vyu7bOn5L8NMmmY4S2G7A28K0ese2Q5CdJ/prktiQXJtm31zW117Cw3fXl9rrmtfvmJTm9HV52QZI7gX9v9+2f5MwkNyX5S5KzkjyvK46Vk3woyZXt0LQb2va2G+PaSPLits2/te0fk2TDrjoLk3wtyR5JftVe6/A42z+wvdZNk5zcHvu7JK9q978iyWVJbk3y8/bbz+5zHznWeXqcd+Q53SXJ/CS3t8/tk9vn6yPtsMCb2uFhD+w4dqmHhyV5efs+GHkdvppk/R7XNK7ns32P/SzJLW29k5Ns3lXn2Ul+2b4Pb23f/+/vaupoYLMkT53oNUkriiRrAE8FjkkyH/hfYP0lHgTpUbbEL7vsgZGkmWulNEOmRlRV3T3ZJ0kzrv/7wFbA+4EFwPOAT9MMAfjPtupngBe0j68A1gGeBjx4jFPsAvyqqm7oOu8LgeOAM4DX0Qwxezyw0SjtHA5cDBwD/Fcbc+fQqMcCnwU+BFwF3NSWz26PXUjz/97zgZOSPLeqftjWeRfwVuA9wHzgQcAQTeI1qiSvB75I8638B2l6hw4EfpFki6rqHN72dOBxwPuAO9o4T0oyu6r+sqTztI4BvgR8kiY5OyLJJsBc4N3AKsDBNOPLnzyO9sbjMcAngA8DtwL/DXy3va1MM579X9o61wPvXJaTJdmP5gPPt4D/AB4OfAR4cpKtqurWjupjPp9tonoizXvl5e1x7wJOa1+f3yd5VHs9x9K8hn8HNgEe1RXefJr32y40Qxgl3df9gL9U1ZwJHHMNzb9jIx4JzFvSASYwkjRzXdb1+AxgzG/sl8Jz23ZfVVVHtmU/br9Rf1uST7fJx7bA16vqyx3HHj+O9p8CnN9ZkCQ0H7bnAztW1ciY6J+O1khVXdN+owdwZVV1D1FaF9i5quZ3Hff2jvPeD/gZTbLzemAkgdkW+HFVHdxx6PeWdFHtN40fB/6vql7dUX42cDmwL/A/HYc8CJhTVX9u6/0ROJfm+b/XpNZRfKKqjmqPHaZJxF4HbFxVN7fl6wMHJ9moqq4eR5tjWQd4alVd1bZ/P5qEYOOqemZb5+Qk29PM2VrqBCbJSjRJyLyq2qOj/DLgNODVNAnqiPE8nwcDv6iqF3a093OaBPdtwAE0ifuqwBtGnkfglO74qmpxkoto3s+Seqiqm5P8Nsm/VtUx7b/1W1TVhUs47GTgI7ln4v7ONF9gjMohZJI0c+0GbNNx23fJ1Zfa9sBi7jth8ms0H+y2bR+fC+yT5D+TDLUfOMfj4cCirrLH0fS0HN6RvCyrhd3JC0CSrZOclORPwD+Au4BntTGMOBd4bpIPJ9kuzbydsWxL8yH66+2QqpXbHrNraJLP7bvqnznyYbu1oL3fkPEZSbZo27keOKvjQzfck/RuMM42x3L5SPLS1f7JXfUuAx7ZflhZWo8DHkqzSMM/VdXpwNXADl31l/h8tr1Tj+a+r8/fgDO55/WZT/OeODrJ7kkeuoQYF9G8nyUBSb5J8/f0uCTXpBkCvBewb5ILgUuAF7Z1t0lyDc2XHf+b5BKAdvL+h2j+HT4X+ODIhP7R2AMjSTPXxVMxib+HtYGbekx4/2PHfmgm4v+R5pvwDwM3pZnY/J6q+tsS2l8d6G57nfZ+MhcTuK67IMkGND0ul9LE/zuaJOZDNEOfRnyEZhjSy2mGyN2a5FjgHd1D3zqMfNAdrdfoz12P7/UfclXd2X7eX32U48dq7++jlE2kzaU552jlKwMr0Ty/S2PkfXaf15Hmfdc9nG+s53Pk9flye+v2u/a43yR5Ns3Qsq8CqyU5F3hnVf2i65jbgfuPfSnSiqGq9hxl132WVq6qc2mGh/Vq5wjgiPGe1wRGkpYfd9D0mPxTmvX1x3ITsHaSVavq7x3lD2vvbwRo5x/8B/AfSTYCdgc+RvPh9V1LaP9GoHtN/5GkYIkrzUxQr0mfuwBrAS9tV18DIMkD7nVg1V00w8E+nuRhwK40c4AeALxslPPd2N7vQ/MtYzeXd56YkYTkYT32PQwYnmB7I6/Pf9A7yfzne72qfg78PMlqNPO6Pgh8v51P05nArs09711JfeIQMklaflwNbN5Vtus4jvsFzf8H/9pVvhfNh7z7LIdbVVdX1adohu10n7PbZdx3QvTlNJPqX7OMw47GMpKo3DVSkOSxNB9Se6qqP1bV4TQfepd0bb+kSVIeU1XDPW6/noT4VyS/Bv4E7NFZ2K76tRHN+3Si7S0EHj/K63NR9wFVdWdVnUKzWMEDgY27qmzctiupj+yBkaTlx9E0K1N9BjgJeCJN78BYfgicDhyaZBZNb8JzgdcAHx35BjrJmTSrNS2gWZFqh/YcXxmj/VOBA5Lcb2S+S1VVkgNoftjylCSH0swv+BfgoVX1gfFe9Bh+SjOk6agkn6JZzvMgmuFD//wSL8mJwIU0iw38GdiSpvfmf0druJ2s+g7g8+3z9kPgrzS9SjvQTEYfz+R8AVV1d7t08f8m+RrNHKxH0AxXvIIJ/v5K+x57I3BiO6fp2zS9J+vRLPP6u6r6dLuS3PbAD2h+i2Jdml6ba2lWvQMgyYNpFn/45LJcp6RlZwIjScuPr9BM3t6XZnWq02gWAljiPJp2daXn0cwDeRfN/JSFwP/j3qtonQq8lGbJ3pVpVnJ6a1V1rgzVy7eAD9Ase/vPb9Gr6sQkz6JZBndkjsKVXedcJlV1SZK9aIYEfbdt/900ycncjqqn0vRAvZGm1+Z3NN/Cf3iM9v83ye+BdwD/RrOU8R/a9uZP1nWsKKrqsCR/o3k+T6RJlH9AMx/l1iUe3Lu9H7QrpL2HZint+9PMpzmLe36X6ELgOcBHaebN3EST0O9VVbd3NPc8mh7J8ay8J2kKZYI/iixJGnBJPg28sqrWncZzzgN+U1Wvma5zSpMpyQ+BG6rqFf2ORVrRmcBI0gqindD/NJrf0rikqsYzP2ayzv00muFcj6mqP0zXeaXJkGQOTa/N5tO0MqCkJXASvyStOLanmSezkOYH/KZNVZ1B80v3G03neaVJ8jCaH3o1eZFmAHtgJEmSJA0Me2AkSZIkDQwTGEmSJEkDwwRGkiRJ0sAwgZEkSZI0MExgJEmSJA0MExhJkiRJA+P/A+h+VQfvmguIAAAAAElFTkSuQmCC\n",
      "text/plain": [
       "<Figure size 864x576 with 1 Axes>"
      ]
     },
     "metadata": {
      "needs_background": "light"
     },
     "output_type": "display_data"
    }
   ],
   "source": [
    "f, bx = plt.subplots(figsize=(12,8))\n",
    "sns.barplot(x='balanza_comercial', y='origin', data=order, estimator=np.median)\n",
    "bx.set_ylabel('Rutas', size=16)\n",
    "bx.set_xlabel('Flujos (cifras en mil millones)', size=16)\n",
    "bx.set_title('Flujos de Exportaciones e Importaciones',size=18)\n",
    "plt.show()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### Medio de transporte utilizado\n",
    "\n",
    "1. Obtener el transporte más y menos usado por Synergy Logistics. \n",
    "    1.1 Se hizo por porcentajes \n",
    "2. Por las 10 rutas más importantes, ver cual es el más utilizado y el menos usado. \n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 85,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "transport_mode\n",
       "Air      2389\n",
       "Rail     3381\n",
       "Road     2598\n",
       "Sea     10688\n",
       "Name: origin, dtype: int64"
      ]
     },
     "execution_count": 85,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "trans= df.groupby('transport_mode')['origin'].count()\n",
    "trans"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "#### **Por Rutas más importantes:**"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 91,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "transport_mode\n",
       "Air     1369\n",
       "Rail     403\n",
       "Road     190\n",
       "Sea      310\n",
       "Name: origin, dtype: int64"
      ]
     },
     "execution_count": 91,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "china= df[df['origin']=='China']\n",
    "china=china.groupby('transport_mode')['origin'].count()\n",
    "china"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 93,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "transport_mode\n",
       "Rail    246\n",
       "Road    434\n",
       "Sea     408\n",
       "Name: origin, dtype: int64"
      ]
     },
     "execution_count": 93,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "france= df[df['origin']=='France']\n",
    "france=france.groupby('transport_mode')['origin'].count()\n",
    "france"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 94,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "transport_mode\n",
       "Air      105\n",
       "Rail     331\n",
       "Road     126\n",
       "Sea     1278\n",
       "Name: origin, dtype: int64"
      ]
     },
     "execution_count": 94,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "usa= df[df['origin']=='USA']\n",
    "usa=usa.groupby('transport_mode')['origin'].count()\n",
    "usa"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 98,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "transport_mode\n",
       "Rail    170\n",
       "Road    259\n",
       "Sea     379\n",
       "Name: origin, dtype: int64"
      ]
     },
     "execution_count": 98,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "rus= df[df['origin']=='Russia']\n",
    "rus=rus.groupby('transport_mode')['origin'].count()\n",
    "rus"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 100,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "transport_mode\n",
       "Air      29\n",
       "Sea    1266\n",
       "Name: origin, dtype: int64"
      ]
     },
     "execution_count": 100,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "s_k= df[df['origin']=='South Korea']\n",
    "s_k=s_k.groupby('transport_mode')['origin'].count()\n",
    "s_k"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 101,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "transport_mode\n",
       "Rail    375\n",
       "Road     47\n",
       "Sea     228\n",
       "Name: origin, dtype: int64"
      ]
     },
     "execution_count": 101,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "c= df[df['origin']=='Canada']\n",
    "c=c.groupby('transport_mode')['origin'].count()\n",
    "c"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 103,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "transport_mode\n",
       "Air     313\n",
       "Rail    112\n",
       "Road    299\n",
       "Sea     940\n",
       "Name: origin, dtype: int64"
      ]
     },
     "execution_count": 103,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "g= df[df['origin']=='Germany']\n",
    "g=g.groupby('transport_mode')['origin'].count()\n",
    "g"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 105,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "transport_mode\n",
       "Rail    160\n",
       "Road    559\n",
       "Sea      77\n",
       "Name: origin, dtype: int64"
      ]
     },
     "execution_count": 105,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "n= df[df['origin']=='Netherlands']\n",
    "n=n.groupby('transport_mode')['origin'].count()\n",
    "n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 107,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "transport_mode\n",
       "Rail    417\n",
       "Road     48\n",
       "Sea     183\n",
       "Name: origin, dtype: int64"
      ]
     },
     "execution_count": 107,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "i= df[df['origin']=='Italy']\n",
    "i=i.groupby('transport_mode')['origin'].count()\n",
    "i"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 148,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "transport_mode\n",
       "Air     573\n",
       "Sea    1129\n",
       "Name: origin, dtype: int64"
      ]
     },
     "execution_count": 148,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "j= df[df['origin']=='Japan']\n",
    "j=j.groupby('transport_mode')['origin'].count()\n",
    "j"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 152,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "transport_mode\n",
       "Rail    199\n",
       "Road     29\n",
       "Sea     910\n",
       "Name: origin, dtype: int64"
      ]
     },
     "execution_count": 152,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "b= df[df['origin']=='Mexico']\n",
    "b=b.groupby('transport_mode')['origin'].count()\n",
    "b"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 145,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "sea:  6198\n",
      "air:  2389\n",
      "road:  1962\n",
      "rail:  2214\n"
     ]
    }
   ],
   "source": [
    "sea=1129+183+77+940+228+1266+379+1278+408+310\n",
    "print('sea: ', str(sea))\n",
    "\n",
    "air=573+313+29+105+1369\n",
    "print('air: ', str(air))\n",
    "\n",
    "road=48+559+299+47+259+126+434+190\n",
    "\n",
    "print('road: ', str(road))\n",
    "\n",
    "rail= 417+ 160+112+375+170+331+246+403\n",
    "print('rail: ', str(rail))\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 154,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "p_sea =  0.5799026946107785\n",
      "p_air =  1.0\n",
      "p_road =  0.7551963048498845\n",
      "p_rail =  0.6548358473824313\n"
     ]
    }
   ],
   "source": [
    "\n",
    "T_Air= 2389\n",
    "T_Rail=  3381\n",
    "T_Road= 2598\n",
    "T_Sea= 10688\n",
    "\n",
    "p_sea=sea/T_Sea\n",
    "print('p_sea = ', str(p_sea))\n",
    "\n",
    "p_air=air/T_Air\n",
    "print('p_air = ', str(p_air))\n",
    "\n",
    "p_road=road/T_Road\n",
    "print('p_road = ', str(p_road))\n",
    "\n",
    "p_rail=rail/T_Rail\n",
    "print('p_rail = ', str(p_rail))\n",
    "\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 171,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "air_p:  0.12536733837111672\n",
      "rail_p:  0.17742443324937027\n",
      "road_p:  0.13633501259445843\n",
      "sea_p:  0.5608732157850546\n"
     ]
    },
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>Participación del Total</th>\n",
       "      <th>Modo de Transporte</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>0.125367</td>\n",
       "      <td>Aire</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>0.177424</td>\n",
       "      <td>Tren</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>0.136335</td>\n",
       "      <td>Carretera</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>0.560873</td>\n",
       "      <td>Mar</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "   Participación del Total Modo de Transporte\n",
       "0                 0.125367               Aire\n",
       "1                 0.177424               Tren\n",
       "2                 0.136335          Carretera\n",
       "3                 0.560873                Mar"
      ]
     },
     "execution_count": 171,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "\n",
    "T_Air= 2389\n",
    "T_Rail=  3381\n",
    "T_Road= 2598\n",
    "T_Sea= 10688\n",
    "\n",
    "Total= T_Air+ T_Rail + T_Road + T_Sea\n",
    "print('air_p: ', str(T_Air/Total))\n",
    "print('rail_p: ', str(T_Rail/Total))\n",
    "print('road_p: ', str(T_Road/Total))\n",
    "print('sea_p: ', str(T_Sea/Total))\n",
    "\n",
    "a=(T_Air/Total)\n",
    "r=T_Rail/Total\n",
    "ro=T_Road/Total\n",
    "s=T_Sea/Total\n",
    "\n",
    "\n",
    "porcentajes = [a, r, ro, s]\n",
    "transporte = ['Aire', 'Tren', 'Carretera', 'Mar']\n",
    "df_p= pd.DataFrame(porcentajes)\n",
    "df_p['Transporte']= transporte\n",
    "df_p.columns=['Participación del Total', 'Modo de Transporte']\n",
    "df_p"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 288,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "image/png": "iVBORw0KGgoAAAANSUhEUgAAAR4AAAEuCAYAAABYs317AAAAOXRFWHRTb2Z0d2FyZQBNYXRwbG90bGliIHZlcnNpb24zLjMuMiwgaHR0cHM6Ly9tYXRwbG90bGliLm9yZy8vihELAAAACXBIWXMAAAsTAAALEwEAmpwYAAA0sUlEQVR4nO3dd3xV9f3H8dfn3uzJvCQ4QAVEQUBwFERxU7Vu67YardYoDto6atpi2qZaW4taNHVbNe6qP/eoyhYXS0XUgCCywggZN/vm+/vjnOAlJCHj3nvOvffzfDzyIPfeMz73cO8737O+XzHGoJRSkeRxugClVPzR4FFKRZwGj1Iq4jR4lFIRp8GjlIo4DR6lVMRp8HSDiBgRGeLg+gfbNSQ4VUNrInKriDxp/76niFSLiDcEy71EROb2vELlJlERPCKySkRq7Q/zRhF5VEQynK4rGtlfZCMi/2z1/Gn284/1dB3GmO+NMRnGmEBPl9VdIvKl/XmpFpGAiNQFPb7Fqbp6QkRmisgvna4jFKIieGwnG2MygLHAwcDvHa4nmq0AzmnVYvoF8I1D9YScMWaEHX4ZwBxgSstjY8xfW6ZzU6uxPWKJpu/qLkXdmzHGrAXeBEYCiMhPRGS+iGwTkSUicmTLtPZf95UiUiUi34nIBfbzHhH5vYisFpEyEXlcRLLbW6eI3CAi60VknYhc2uq1ZBH5h4h8b7fG/i0iqR0s63IR+cquaZmIjLWfv1lEVgQ9f3rQPF57HZtFZCVwUqtl5gUtc6WI/GoXm3ED8Dkw2Z6/DzABeKXVcjvatnuJyCx7ne8C/YJe22FXUEQGisgrIrJVREpF5PIOtk9fe9pKEfkY2KfV68NF5F17WV+LyNm7eK+tl99S22Ui8j3wvv388yKyQUQqRGS2iIwImucxEblXRF633+9HIrKP/ZqIyHT7c1QhIktFZGTQfP+2662yt9egoOVOEJFP7Pk+EZEJQa/NFJEiEZkH1ABPAIcDM8Rqtc0IxfZwjDHG9T/AKuBY+/c9gC+BPwO7AVuAE7FC9Dj7cX8gHagE9rXnywVG2L9fCpQCewMZwIvAE+2s+6fARqygSweeAgwwxH79LqwvbB8gE3gVuK2dZf0cWIvVYhNgCDAo6LWB9vs4B/ADufZrVwLL7ffeB/jAriHBfv0krC+oAJOwPqhj26nhEmAucD7wrP3cVcD9wF+Ax+zn2t229usfAv8EkoEjgCrgSfu1wa3qmwXcB6QAY4BNwDHt1PcM8Jy9rUfa22uu/Vo6sAbIAxKwWr+bW/5fO/j8zAR+2aq2x+3lpQZ9JjLt93MXsDho/seArcAh9npLgGfs1yYDnwG97O2/X9D/22P2djnCXu7dQe+lD1AOXGQv8zz7cd+gmr8HRtivJwa/j55sDzf8OF5Ap4q0gqca2Aastj/EqcBNtAoM4G3gYvs/ZRtwZsuHK2ia94Crgh7vCzS2fFFaTfsIcHvQ42H2B3eI/UHzA/sEvT4e+K6d9/E2cF0n3/Ni4FT79/eBK4NeO56gL3Yb877c3nr4MXhSsQI1G1gAHMaOwdPRtt0TaALSg157ijaCByssA0Bm0LS3tayn1fK99v/D8KDn/hr0ZT0HmNNqnvuBabvYltu/sEG17d3B9L3sabLtx48BDwW9fiKw3P79aKxd1J8AnlbLeQw7oOzHGfa22AMrcD5uNf2HwCVBNf+pvffRk+3hhp9o2tU6zRjTyxgzyBhzlTGmFhgE/NzeFdgmItuAiVh/cfxY/zFXAuvtZvJwe1kDsQKsxWqsL8mANtY7EOuvSvC0LfoDacBnQet/y36+LXtgHV/ZiYj8QkQWBy1nJD/uvnRUAyJygogssJvb27C+GP3ogL39Xsc6VtbPGDOv1STtblu7nnJ7G7dZU5CBwFZjTFWraXdrY9r+WP8P7b3XQcChrWq6AMhp/522a/s67F3Z2+1d3UqsP3Sw4zbcEPR7DVaIYIx5H5gB3AtsFJEHRCSrrfUYY6qxWk4D2fkzCDtvlzV0LJTbI6KiKXjasgbrr3KvoJ90Y8ztAMaYt40xx2F9WZYDD9rzrcP6T2vR8hd8YxvrWI8VGMHTttgM1GI1bVvWn22sA5rt1btP6yft/f4HgSlYTe1ewBdYLaoOaxCRZOC/wD+AAfa8bwTN25HHgd9gHT9oq9b2tu16oLeIpLdVUyvrgD4iktlq2rVtTLsJ6/+hve29BpjVqqYMY0x+h++ybcHdMpwPnAoci9UCHGw/35ltiDHmHmPMOKzdomHADUEvb38vYp2J7YO1TVp/BmHn7dK664jWj0O5PSIq2oPnSeBkEZls/9VKEZEjRWR3ERkgIqfYX456rF21ltO7TwNT7QOkGVjN+WeNMU1trOM54BIR2V9E0oBpLS8YY5qxAmO6iPgARGQ3EZncTr0PAb8VkXH2QckhduikY32oNtnLyMM+eB5Uw7X2++oN3Bz0WhLW8YNNQJOInIC1K9YZs7CO3fyrjdfa3bbGmNXAp0ChiCSJyETg5LZWYIxZA8wHbrOXMQq4DOs4SetpA1jH224VkTQR2R9r167Fa8AwEblIRBLtn4NFZL9Ovt/2ZGJ9RrZgtWD/2vHkP7LXf6iIJGLtdtfx4+cM4EQRmSgiSVjHJT+yt8kb9ns5X0QSROQcYH/7PbZnI9ZxyRbh2h5hF9XBY/8HngrcgvXFW4P118Zj//wG6y/LVqyDrlfZsz6C9Vd+NvAd1oflmnbW8SbWwcb3sQ5Iv99qkpvs5xfYzfT/YR0zamtZzwNFWMdDqrCOxfQxxiwD7sTax98IHAAE7/o8iHV8ZQmwEOvL2bLMKuBarHAqx/rrvcPZqfYYy3vGmK1tvNbRtsVez6FY23YaVuupPedhtSLWAS9hHYN4t51pp2DtxmzAOkbyaFBNVViheq69rA3A37CCtycex9rNWQsswzrm1VlZWP8/5fYytmC1Pls8hbV9tgLjsHaFMMZsAX6G9RndAtwI/MwYs7mDdd0NnCUi5SJyTxi3R9iJfUBKKRViYl2M+YMxRq85ayWqWzxKqeikwaOUijjd1VJKRZy2eJRSEafBo5SKOA0epVTEafAopSJOg0cpFXEaPEqpiNPgUUpFnAaPUiriNHiUUhGnwaOUijgNHqVUxGnwKKUiToNHKRVxGjxKqYjT4FFKRZwGj1Iq4jR4lFIR5/oB65UCa0x1rBFgwRqwLoA9HBBwiDGmwZHCVLdo16cq6ojIrUC1MeYfQc8ltDMumnIhbfGoqGUPH7MVOBBYKCL3YQ0l3B9rmOHLjTHL7ekqgYOwWks3GmNecKRoBWjwqOg3DDjWGBMQkfeAK40x34rIocB9wNH2dLlYY78PxxrwUIPHQRo8Kto9b4dOBjABeF5k+5DnwSNqvmwPOb1MRAZEuki1Iw0eFe389r8eYJsxZkw709UH/S7tTKMiRE+nq5hgjKkEvhORnwOIZbTDZal2aPCoWHIBcJmILAG+BE51uB7VDj2drpSKOG3xKKUiToNHKRVxGjxKqYjT0+kKgNKpMzKAQcBgYA+gN5AFZNr/Bv+ehHWvVCPQFPTTCDQA5UBZOz8bhkyf0hiht6VcSg8ux5HSqTOSgJHAWGA/rJAZjBU4fSNURhOwElhu/3zV8u+Q6VMqIlSDcpgGT4wqnTojFRiDFTJjse5nGoHVWnGr9cBnwEfAAuDjIdOnVDpbkgoHDZ4YUTp1hhfrJsjjgGOB8bg7ZDqjGVgCzAbmAB8MmT5lq7MlqVDQ4IlipVNnDAGOxwqao4BejhYUfgFgLtZNnq8MmT6l1OF6VDdp8ESZ0qkz9gN+bv+MdLgcp32FHULAgiHTpzQ7XI/qJA2eKOAvyRsIXNjc5D1q4+IxP3W6HpdaBzwBPDJk+pRvnC5GdUyDx6X8JXnpwJnARVh9yngANi8b/m1jTfpQJ2uLAvOAR4DnhkyfUu10MWpnGjwu4y/J2wP4DXAZkNH69bpt2bPKS4dMinhh0ckPPA88MGT6lA+dLkb9SIPHJfwlefsBNwHnA4ntTWeaZfWGhWMHRayw2DEPuAN4dcj0Kfqhd5gGj8P8JXmHAr8DTqGTHVRtWT5sWUN15v5hLSx2LQP+DpToFdTO0eBxiL8kbzJwM3BkV+etr8yctfWbYbq71TM/ANOxdsP0OFCEafBEkL8kz4N1GvwmrCuJu8UY1m/4bGwOiHbh2XNlwK3Ag0OmT9HhcSJE706PEH9J3uFYV+E+Qw9CB0CE3OTsyqUhKUz5sEaj+KJ06gztsTBCtMUTZv6SPB/WMYVfhHK5DdXps7csH35EKJepAOv2jBuGTJ/ysdOFxDINnjCxd6uuBIoIw60MxrB5w2dje4N4Q71shQGeBX47ZPqUtU4XE4s0eMLAX5J3MFAMjAvnespX7LWwrrzP2HCuI85VADdiHf/RL0oI9egYj4jkiMgzIrJCRJaJyBsiMixUxdnr6CUiV4VymeHiL8nr7S/J+zdWlw5hDR2AjNwNNeFeR5zLBu4H3rdvyFUh0u0Wj1jDNc4H/mOM+bf93Bgg0xgzpxPzij2y406PW007GHjNGNPpGyI7Wl44+EvyBLgE+BvWuN0RYQwVGxYemIrxRHv3F9GgFuvs151Dpk8JOFxL1OtJi+cooLEldACMMYuBRSLynogsFJHPReRUsAJERL4SkfuAhcDhrR7vISI3iMgnIrJURArtxd4O7CMii0Xk7/aydpqujeXvISLFIvKpiHwZtLyQ8pfk9QPexLo3KGKhAyBCdmrfLYsjuc44lor1h+Wj0qkz4r1XgB7rSfCMxOotrrU64HRjzFiscLpTfhzMel/gcWPMgcDqVo/3BYYCh2D1nDdORI7AushuhTFmjDHmBhE5vp3pdli+MWY1UGCMOQgYBUwSkVE9eL878ZfkjQcWAZNDudyuyBiwUa89iaxxwMelU2dc7nQh0Swc1/EI8FcRWQr8D9gNGGC/ttoYsyBo2uDHx9s/i7BaLMOxAqa1jqZrvfyzRWShPe0IIGS3GfhL8q4HZgG7h2qZ3eFNqR8tnoAe64msVOCB0qkznrQ7yVdd1JPg+ZK2D6BegLXLMc4YMwbYCKTYr/lbTRv8WIDb7JbNGGPMEGPMw20sv6Ppti9PRPYCfgscY4wZBbweVEe3+Uvysvwlec9jXW7f7s2ckSJCemq/zUucriNOXQB8Wjp1Rkhb0vGgJ8HzPpAsItubnCJyMNaIBWXGmEYROcp+3BlvA5eKSIa9rN1ExAdUYQ2rsqvpWsvCCqIKERkAnNC1t7czf0neKOBT4KyeLiuU0geU6RXoztkX67jPFU4XEk26Pa6WMcaIyOnAXSJyM9axnVVYR/7vEZFPgcVYQ5d0ZnnviMh+wIf2IaFq4EJjzAoRmSciXwBv2sd5dpoOqz/e4OUtEZFFWC2zlVjdInSbvyTvEqxL61N7spxw8CY1jBFvU4UJJGQ7XUucSgHuL506Yzxwhd71vmt6AeEu+EvyUoB7gUudrqUjVWsHzqten3uY03Uo3gfO0DHCOqZN9A7Yp8pn4/LQAUjrv6nHx69USBwNzC+dOkM7a+uABk87/CV5g7CGUjnY6Vo6w5PYONqT0LjF6ToUYJ09/ah06oyDnC7ErTR42uAvyRuBdUxoX6dr6SwREtIHbFzmdB1quwHArNKpM05xuhA30uBpxb4ocDbW9UdRJa3/5iyna1A7SANeKp0645dOF+I2GjxB/CV5RwHvAn2crqU7xBs4wJPYsMHpOtQOPFgXG0bFjc6RosFj85fkHYt1kWG607V0lwiejNwNXztdh9qJAPeWTv3XNU4X4hYaPGzveP1VXHiNTlel9t3Sz+kaVFtMRXZG5a8qCguvc7oSN4j74PGX5J0A/B8huJ3CDTze5hHe5Lo1TtehgpmK7PTKH5ISmkYAd1UUFl7pdEVOi+vg8ZfkHQG8BCQ7XUsoZeSuX+l0DaqFqcxOr/whKbFpRNCT91UUFrr+2rBwitvg8ZfkDSUGQwcgtXd5rtM1KLBDZ02r0AHrmM+DFYWF5ztRlRvEZfD4S/J6A68RpWevdkW8ZlhCas0Kp+uIb6YqO73q+zZCp4UHeLSisHBCJKtyi7gLHn9JXiLwIhDSvqHdJmPg+h+criF+mars9KpVSYmNu+qpMAl4saKwcI9IVOUmcRc8wL/pxrDB0SYlu2JPp2uIT9tD54BOzjAAeKWisDAtnFW5TVwFj78k70ai4IbPUBCP2Ssxo7pTXZKoUDHV2elV33UhdFqMAf5TUVgYN0NSx03w+EvyTsfqOD5uZOSu3+h0DfHDVGenV61MSmzsbm+EZwF/DGVFbhYX/fH4S/LGYd1/FVfNWWNYu+GzsQNBQvaX9OZ3Svjguy/om5bJGxfdAsB1rz/CyvIyAKrqa8lMTuXVC2/eYb6VWzdy3RuPbn+8pnIL1/3kRPLGHrX9uYc+e4+/zXmZj351G31SM/hs3Uqmvf8sSd4Epp9wCYN69aeyrobr3niUR06/Cgnd2+ohU52VXrUyufuhs31BwM+zp037byiqcrNu90AYLfwlebtjXZUcV6EDIMJuyVmVn9dXZne16d+uM/Y/lIvGHMENbz+x/bm7T/px7/W22S+SkbTzBeB79xmwPYwCzc1MfOj3HD9k9PbX11eVM2/1cgZm9t7+3MOfvceMky7jh8qtPLV0Dr874gzu/fgtrjzkeDeFjj8rvWpFcmLj6F1Pu0uCtctVmj1tWkz3ox3Tu1r2+OXPAnF7XUtG7obyUC7vkN2HkJ3cdoYbY3jjm0WcvG/Hg6jOX/M1e2b3Y7esH69mKJr1IjcefirCj4GS6PFS19RIXVMDCR4vq7dtYmN1BYfu3tbgI04w/qz0qtIQhU6LdKyDzW31Ix4zYr3FcwMQl9dJtEjMqN4PTADEG+51fbJ2Bf3SMhncu+PvzOtfL+RnQeH03orPGZCRzX79dxwp6FcHH8/v33uGlIRE/j75Iv4252WuH39SWGrvOuPPSq/6NjmxcUwYFr4n8CjgljcbcjHb4rE78wrL6KHRRIT+Kb22LY3Eul77+rMdAqUtDYEm3l/5OScMPRCA2sYG7vv47TYDZX/f7rxw7m948qxrWVOxBV96NgbrmNJv3voPm/2V4XgbnWBqwhg6LU6sKCzMC+PyHRWTweMvyUsAHicGb4fojvTcDdXhXkdTc4B3VizhxGFjO5xu9qpl7O/bg37pVp9l31ds5ofKLZz85O0c+fA0NlRv47Sn7mBTUKgYY7jv47e5+tCf8q8Fb3Lt+BM5dfjBPL54VljfU9tMTVZ61TdhDp0W0ysKCx0dMDJcYnVX6/dAx9+AOJKYVjMSaW7EeMI2AOH8779m794DyA06ONyW1q2iffsN5KNf3bb98ZEPT+PF82+gT+qPA3S+uOwjjtxrBNkpadQ1NeARDyJCbVND6N9Ih0xNVlrV18mJjQdGaIXZwIOEYEw4t4m5Fo+/JG8sUOB0HW4iQu/UPlsXh2JZ17/xKGc/+0++K9/IxIf+wPNffAi0vZu1sbqCX75cvP1xbWMD875fzuQhnT8WW9vYwEtffcwFow4HIG/sUUx57SHunPcq59vPRYapzUqr/jo5KWKh0+KnFYWFMdd1akxdx+MvyUsGPsMaJ10FaaxNmb/5yxFxfaC9+0xtVlr1V8lJDU61oiuBA7KnTfveofWHXKy1eP6Mhk6bElLqDkCaa52uI/o4HjpgDcf9sIPrD7mYCR5/Sd4E4DdO1+FWImSm9dsc0xelhZ6py0yrXuZw6LQ4tqKw8FdOFxEqMRE89jDDjxEj7ydc0gforVudZ+oy06q/TElq6Pj6gMj6R0VhYUyMUBorX9QpgFsuZ3Utb3LDGPEEqpyuw/1cGToAGcTIjc5RHzz+krxs4HdO1xENREhJ85VF5GLC6GXqM9Oqv3Bh6LQ4p6Kw0A27fj0S9cED3EiMdmEaDum+TUlO1+Bepj4zrfrzlKQGN495LsRAqyeqg8dfkpcDXO90HdHEk9g4RrxNIb1xNDZERei0OK6isPAYp4voiai+jsdfkncfkO9kDfkPzOXNxT/QPyuFT24/DYA/Pb+Q1xeuwSPQPyuV+381kdzeO9/Rvc1fz9UPzWfZD+WICMWXH8ahQ33tzv/hNxu5/tEFJCd4ePTqSeyTk8U2fz0Xz5jFyzce1+muIqrW5cypXrdbJK++czlTn5lWvTQlqeFgpyvpgk+BQ7KnTYvKL3DUBo+/JG8I8BUO3/Yxd/kGMpITufz+OduDp7Kmgaw0a4/mvreXsXztNu65dOdr96749xwm7DuAS44aRkNTgJr6JnqlJ7c7/3l3vc+fzz2I7zdV8+7Stdx2wcH8ruQTThy7B4fvl9PpmgONCYvKloyO9BW4LmUaMtP8S1KS6qMpdFqckz1t2nM9WYCInI41+MF+xpjlIjIQuMcYc1ZIKmxHNO9q/RkX3Gs2cXgOvTN2PGzSEhoANfVNbbZEKmsamPf1Ri4+0joZl5TgpVd6cofzJ3o91DU0UdPQRKJXWLmxknXl/i6FDoAnoWm0J7GhrEszxaSoDh2Av1QUFvb0O3AeMBc4F8AYs66t0BGRkH7XHP/idoe/JO9A4Byn6+jIrc8t5Om5pWSlJfHGLT/d6fVVm6rol5nClQ/M5fPvyzlwcF/uuOgQ0lMS253/t6ccwDUPzyclKYGHrjycW57+hD+c1fUTHCJ4MnI2LK9cs2dMdzbVMdOQmepfnJJUf4jTlfTAUOByoHhXE7ZFRDKAw4CjgFeAW0VkMPCaMWakiFyC1SdQCpAuIicD/wIOwMqOW40x/9eddUdri+c2wC19X7bp1rPH8vU9Z3POhL25/92vdnq9KWBYvGoLvzxmOPOLTiEtOYE7X/28w/lHDerLB4U/482Cn/Ldpipye6VhjOEX/5rJZffNZmNF5++ISO27NY7PBJqGjFT/4pTkqA6dFn+sKCxM7+a8pwFvGWO+AbaKSFt/xcYDFxtjjsa6+fp9Y8zBWGH1dxHp1rqjLnj8JXlHApMdLqPTzp6wN//3yeqdnt+tTxq79Unj4CH9ATjtkMEsWbW1U/MbY7jj5aXcdPpobntpCQVnjuHcw/am+O2dA6494g2M8CbXx+Ggf6YxI9W/ODU2Qgcgh+6fYDkPeMb+/Rn7cWvvGmNaPpjHAzeLyGJgJlZLqFvjt0Vd8BAFFwuWbvixE6vXF65hWG72TtMM6JXGbn3S+WZdBQAzv1zH8N2yOzV/yZxSJo/Znd7pydTUN+ERweMRahuaOl2jCJKRsz7Ohjk2jRmp/oUxFDotrqkoLOxS17Yi0hc4GnhIRFZhdRN8DjvvSfiDZwPONMaMsX/2NMZ0/q9dkKg6xuMvydsXOM7pOoJdMmMWc77awJbqOoZd8xwFZ47h7SVr+XZ9BR4R9uyXzt154wFYX17D1Q/N48UbrLdw58WHclnxbBqamtnLl0HxFRMB+OOzn7U5P1gHm0vmrOCVm44H4JoTRnDB3R+QlODl0auP6FLtKX3KB1SsHhyCrRANtofOoU5XEgZ7AqcDL3RhnrOAx40x2288FZFZQEc9Hr4NXCMi1xhjjIgcaIxZ1J2Co+p0ur8k7x7gGqfriCWbvtz/u6ba1L2criO8TGNGqv+z1OT6nzhdSRjNzZ42rdPXZonITOB2Y8xbQc9di9Xb4R5BB5cPMsZMsV9PBe7CGkBBgFXGmJ91p9ioCR5/SV4msBbIdLqWWFK7tfesbSv3nuR0HeFjmjJS/Z/GeOi0GJc9bdpCp4vojGg6xvMLNHRCLqXXtpjsTNwSV6EDUbQ3EDXBU+vve3ggkFjqdB2xRjxmn8T06m+criP0TFNGas0ncRQ6AGdXFBbufCbDhaIieMqKCw5tDiSfU+fvP8RfmbO0oT5jnjHUOV1XrMjI3bDO6RpCqyV06sbvetqYkgZc4HQRnREVwQMEDWzmGdVYn3VYTVVuba2/76zmQMJK58qKDcnZFUOcriF0TFN6fIZOi8udLqAzXH9wuay4IBVYjzXGUNukeUliUlV1YpL/IBEdxK87tnw99MuGqqwo7yjfBNJTaz5Oi9/QaXFw9rRpnzpdREeiocVzBh2FDoDxjG6szz6spiq3utbfZ1ZzIOG7yJQWOzJy129xuoaeMYH0lJqPNHQA60SMq0VD8HRh/Gjp2xxImVTr7z/YXzVgUWN9+nxjiPRwk1EpKbN6GJhmp+voHjt0Uup03DDLyU4XsCuu3tUqKy7oA2yiRwFpNnsT6r9ISq7cy+Ntioke+sNla+k+S+q39er8MJ+uYALpKTUL0lLqDnO6EpcZnT1tmmv713Z7i+c4elyj9As0pRxZ6++/p79qwMLGhrQPjaExJNXFmIycDRVO19A1GjodOMXpAjri9uDZuSObbhPBeMc21PUaX1OVW15X02dmc8C7JnTLj36J6f6RYDp/p6mjTLOGToc0eHrg+PAsVnxWK8i3e03VgE8bG9IWGEOUfOHCR4Q+KX22Lna6jl0zzekpNR9q6HTooIrCwlyni2iPa4OnrLhgFDAwvGsRMcZ7UENdr5/UVOVurqvpPbO52bs2vOt0t4ycjfVO19Ax05yWUjtfQ2eXBOjWDZyR4OZuMSLc2ZfkBJpSc2qrU5pFmj9JTK4yCYk140ToUj8n0S4htfYApLke43Hh9VBW6KSn1E7sylxXv/wyb3/zDf3T0/nw6qsB+MM77/DW11+T6PWyV58+3HvqqfRKTd1p3gOmTyczORmPCAkeDzN/tePw5f+aN48/vPsuK264gb7p6Sz4/nt+/dprJCck8PCZZ7J3375sq63l0hde4L8XXtjpkUBC5BTgwUiusLNc2+IhpMd3ukI8xngPbqjrdUhNVW6Z3Qpa70wtkSdCVlrfLYudrmNn3QsdgPPHjOGFCy/c4bmj9t6bD6+6ivlXXcWQvn2ZPnduu/O/evHFzM3P3yl0fqio4IOVK9k9+8fLzGbMn88T55zDH485hoc/ta7h+/vs2fz68MMjHToAx1QUFu48rpILuDJ4yooL0oEuf8BCT3IDTalH1lb7fDVVvo8bG1I/MYYovdal89JzNrrsPXY/dAAOGzyY3q1aM0cPGUKC12rMHrT77qyrrGxr1g7d8tZbFB533A5d9iV6vdQ2NlLT2Eiix8N3W7eyvrKSiYMHd6f0nkrFZR3ntXDrrtZRgIuG2hWvMQmHNNT1pqGu11pvQu23SSmVwz2e5q6NKxMlvMn1o8UTqDbN3gynawFj0pK7Hzqd8eSiRZwxou27RUSE0594AhEhb9w4LjnIGmj0jeXLyc3K4oCcHT8CUydO5PpXXyUlMZH7Tz+dP7zzDgVHHx2u0jvjBKBbI0GEk1uDx8Wductugaa03WqrU5tEAh8lpVR5vQm1Y0Xc2XrsDhHS0vpvmu/fmOPwlcDGpCXXzk1PrQ3bqKf/mD2bBI+Hs0eNavP1ty+9lNysLDZVV3PaE08wtF8/Dhw4kDvnzOHFiy7aafpRubn873LrPs15q1aRk5mJMYa8558n0ePhL5Mn48uIaJ67cswwt35ZHDq+0xWSYEzCofW1vQ+qqcpdV1fba2ZzsydmBslL921y+I9S+EPnqcWLefubb3jwjDPaPf6Sm5UFQP+MDH42fDgL167lu/JyVpeXM7G4mAOmT2ddZSWT7r+fjVVVQdUb/jF7NjdOmsTfZs3id0ceydmjRnH/Rx+F6+20Z2RFYaGL9h4srmvxlBUX7AFEWTcNsnugMW332sbUJpHAgqSUyiRvQt2BIu4e+6sjnqSGMeJtqjCBBAc6lgp/6Pzv22+5e+5cXs/LIy2p7e+lv6GBZmPITE7G39DABytWcOOkSYwYMIDSG2/cPt0B06cz84or6Jv+4xBTTy1ezPHDhtErNZWaxkZrJBARahojftF8EtYAfJ9FesUdcV3wAG23eaOCJBiT8JP62j6A+T4hsXZlYnLlCI+nub/TlXWVCEnpA8o+ql43MGxf/rYZkxri0LnshReYu2oVW2pq2P/OO7n5qKOYPmcODYEApz3+OAAH7747008+mfWVlVz7yis8f+GFbKqu5oJnnwUg0NzMWQccwLFDh+5yfTUNDTy9ZAkv2btiV48fzy+ee45Er5eHzzwzVG+rK8bhsuBx3U2iZcUFNwB3OF1H6JhG8QQ+TUquTPEm1I2JplZQoDFhYdmS0V0fI7nbjElNrpuTkVrTtXF61K48mD1t2hVOFxHMjS2e/Z0uILQk0TQnjLdbQasSEmtWJyVXjRRPc1+nK9sVT0LTaE9C46bmpsQItNg0dMJonNMFtObGg8sxFjzBZHBTY/qkmuoBmTXV/ec3NaYsdrqijojgTc/Z0K2RIrtGQyfMXHeA2Y3Bs5/TBYSfJJnmxAn1tX3G+Ctzv6uvzZ5lmj07D5zuAmn9tvQK9zo0dMKu5QCza7gqeMqKC3Yn7sbOkr3sVlB6TXX/eU2NyUucriiYeAMHeJPqw3bLSGpy7WwNnYhw1e6Wq4KHmN7N2hVJNs2Jh9XX9h3tr8xdUV+bNcsY2eZ4VYKk524Iy7hbqcm1szR0IkaDpwNxHDzBZJ+mxoxJNVU5yTXV/ec2NSV/7mQ1qX22+kK+zKTaWRmpNTE8dLLruOraOLed1dLg2YGkmubEifU1fanHfJuQ5F+XlFw1RsRE9KI+j7d5v4SU2tVNdakh6bM6Nal2Vkaahk6EuapTMG3xRA0Z2tSQMammKiextrr/3EBT0peRXHtG7oZVoVhOioaOUzR4OhAHZ7R6StKamxMn1tX0G+GvzPm6oS5rtjHS9T4duiild/luPV5GUt2sTA0dp/SqKCxMcbqIFq4JnrLigmygj9N1RBfPvo0NGUfUVOV4a6v7zQk0JS0L15rEY4Ykpvm/7e78Vuj4NXScFeauhDvPNcHDrkYLVR2Q9ObmpMPravrt76/M+aqhLnOOMVId6rVkDFy/rjvzaei4hmt2t9x0cDnOrt8JF89+jQ2ZNDZkVHm8jbOTkit83oTG4aFYcnJW5eCuzqOh4yquCR43tXiynC4gtkhmcyDpiLqa/sP9lTnL7FaQv0dL9JhBSRlVnd6dS0mqm6mh4yoaPG3QFk/YePZvbMg8vKYqJ1Dr7zc7EEjs9gWBGQPXb+rMdHboHNnd9aiwcM0xHt3ViiuS1RxIOqLO3x9o/iIxuXpbYpJ/rIjp9EgESZlVw8AYaH/IhGQNHbfSFk8bdFcrojwjG+uzJtZU5TTW+vvODgQSSzszlwi5ydmVS9t7PTmxbmaWho5bDXC6gBba4ol7kt0cSG5pBS1NTK6uSkyqHidCu9d8ZOSur6iv2PkkZHJi/cysdA0dF3PNII1uCh5t8TjOM6qxPovG+sxyj7fh46SUit283qZ9Wk+VmO7fH0wAZPsoq1boVB8Z0XJVVyU6XUALN+1qaYvHNaS31Qry7eOvzFnSUJ8xzxi2j6kuQr+U3uXbu+/Q0IkarmlouKYQNHhcyjPabgVt9XgbFiSnVOzp8TbtlZG7oaauvI+GTnRxzffdNYWgu1ouJ32aA8mTav0+kMDihISapuSUmrcy02oONLDR6epUp4T8avbuclPwuGb/U+2C8Y5paswkec8KGpyuRXVFt255CQc3HeOpdboApWJck9MFtHBT8NQ4XYBSMS7iw5i2R4NHqfihwdMGDR6lwkt3tdqgwaNUeGmLpw1h775TqTi3xekCWrgpeFyzUZSKUT84XUALNwXPZqcLUCrGafC0QYNHqfBa43QBLdwUPLqrpVR4aYunDdriUSq8tMXTmi+/qA5t9SgVLvVAp/rLjgTXBI8tbAPSKRXn1vryi4zTRbRwW/B84XQBSsUo1xzfAfcFz5dOF6BUjNLg6YC2eJQKD9ccWAb3BY+2eJQKDw2e9vjyizaj3WgqFQ6LnS4gmKuCx6atHqVCqwH4zOkigrkxePQ4j1Khtci+Ts413Bg82uJRKrQ+dLqA1twYPNriUSq0NHg6QVs8SoWWBs+u+PKLKtDwUSpUfvDlF7nqVDq4MHhsbzpdgFIxwnWtHdDgUSrWafB0wVygyukilIoB850uoC2uDB5fflED8J7TdSgV5eqBRU4X0RZXBo9Nd7eU6pmP7D/irqPBo1Tset7pAtrj2uCxTwHqaXWluieABk+3aatHqe6Z5csvcm1PDxo8SsWmZ5wuoCNuD565QLXTRSgVZRqB/zpdREdcHTz2Efm3nK5DqSjzP19+0Vani+iIq4PH9qDTBSgVZVy9mwXRETzvAiucLkKpKFEHvOx0Ebvi+uCxByG73+k6lIoSb/ryiyqdLmJXXB88tkexLv9WSnXsWacL6IyoCB579IkXnK5DKZfzA686XURnREXw2IqdLkApl3vUl19U43QRnRE1wePLL5oHfO50HUq5VDNwl9NFdFbUBI9NWz1Kte1lX35R1Jz9jbbgeRK9klmpttzpdAFdEVXB48svqgJKnK5DKZdZ4MsvcmVPg+2JquCx3QsYp4tQykXucLqAroq64PHlF30OvOh0HUq5xOdEwZXKrUVd8Nj+gHUUX6l492f76v6oEpXB48sv+grrQLNS8exLovTC2qgMHtutWP2OKBWv/hKNrR2I4uDx5Rd9BzzkdB1KOWQZ8JzTRXRX1AaPrRAd+E/Fpym+/KKoPc4Z1cFjd2b9V6frUCrCnvTlF33gdBE9EdXBY5sOfOd0EUpFSDnwG6eL6KmoDx5fflE9cJPTdSgVIbf48ovKnC6ip6I+eAB8+UXPA3OcrkOpMPsYeMDpIkIhJoLHdhXaS6GKXQHgymg+oBwsZoLHl1/0BXCL03UoFSYzfPlFi5wuIlQSnC4gxKYDJwFHO11IJB30+3tJT0nC6xESPB7euflSAB764BMemfUZCV4Px44Ywh/P2HmzvP/lCn7//LsEjOGCCaO5dvIEAL78YSM3PP0W/voG9uiTTXHeqWSmJvPxijXc+PRbJCck8O9LT2UvXx8qauq44uGXeGbKuYhIRN97nFiHdZtQzIip4PHlF5my4oJLgKVAL2eriawXr7+Avhlp2x/P/XoVby39lg8KfklyYgKbqvw7zRNobubmZ9/muWvPY2CvLCb/7VEmjxrKvrn9+fWTbzDtjKOZMGwQT81fwr3/W8DNJ0+i+H8f8cgVZ7JmSwWPzVlI4ZnH8s8353Ld5AkaOuEz1e4SJmbEzK5WC19+0RpgitN1OO0/cxZyzeTxJCdaf1v6Z6bvNM3CVevYq39vBvfrTVKCl9PG7c9bS74FoLRsC+OH7gnApOF78fqi5QAkeL3UNjRR09BIgtfLqk3lrN9WxYRhgyL0zuLO2778oqi9Qrk9MRc8AL78ohKiZJiPkBA4519Pc9xtj/D4XOswwIqyrXxUuoaf3vEYp/3zCRatWrfTbBu2VTGwd9b2xwN7Z7KhwvrDOjy3P28ttULo1UVfsbbcev66yRP47VNv8MD7H3PZpHH89ZWZ3HzypHC/w3i1AchzuohwiKldrVbygYnAbk4XEm6v/eYX5PTKZFOVn7PveZqhA/rSFGhmW00db95wMYtWr+fyh1/ikz9dtcPuUEd3F9510UkUPPcu/3xjLpNHDSUpwQvAyD0G8OaNlwDw4bffk5OdiTGGyx96iUSvh1vPPAZfVkYY323caALO9uUXrXe6kHCIyRYPgC+/qBy4hDjorTCnVyZg7U6dOHoYi1atY2DvLE4asy8iwtjBA/GIsKV6x5FPcntlsq78x0En15VXkZNtLWtoTj+eu/Y83v3dpZx+0P4M6tdrh3mNMUx/cx6/PvEw/vHGXG782eGcdchIHvrg0/C+2fhxky+/KGavTYvZ4AHw5Rf9D/iX03WEk7++geq6+u2/z/zqO4YP7M8Jo4Yx9+tVAKzYuIXGpsAOB58BDhw0kJVl5azevI2GpgAvf7aMyaOGAmw/GN3cbAXMxYeP3WHeZxd8zrEj96FXWiq1DY14RPCIUNuoPZWEwPO+/KJ/Ol1EOMXyrlaLm4Bjgf2dLiQcNlX5ybv/v4B1lur0g0Zw9Ih9aGgKcP0Tr3HEnx8gKcHLPRefjIiwYVsVvy55g6euPocEr4fbzjmec2c8Q6C5mfPGj2b4wP4AvPTJlzw6eyEAJ47Zl/PGj9q+zpqGRp5dsJTnrj0PgCuPOYRLH3yRJK+Xf196aoS3QMxZDlzqdBHhJsbE/J4IZcUFQ4EPgb5O16JUB6qBQ+weNmNaTO9qtfDlF30LnALUOV2LUh24LB5CB+IkeADscYcuRDuJV+50Vyxer9OeuAkeAF9+0X+BG5yuQ6lW5hJnn8u4OMbTWllxwd3AtU7XoRRQChzuyy/a4HQhkRRXLZ4gU4nCQdBUzFkFHB1voQNx2uIBKCsuSAU+AA51uhYVl34AjrBHS4k7cRs8AGXFBf2xTrPv43QtKq6sBybZZ1vjUrzuagHgyy/aBJwAbHa6FhU3NgHHxHPoQJwHD2y/xucorM6WlAqnrcCx8XKtTkfiPnhge7epE4C4/iukwqoCOM6XX7TU6ULcQIPH5ssvWg0cBix0uhYVc6qAyb78Iv1s2TR4gtjHfI7EOtulVCj4gRN9+UUfOV2Im2jwtGL3bXsC8KLTtaiotw7rlPlcpwtxGw2eNtijk/4ceNDpWlTUWgIcqrtXbYvr63g6o6y4oAgdr0t1zRvAOb78omqnC3ErbfHsgi+/qADrFgtNaNUZM4BTNHQ6pi2eTiorLvgZ8DjQ2+lalCvVA1f78osedrqQaKDB0wVlxQWDgOeBg52uRbnKD8CZvvyij50uJFrorlYX2Nf6TMRqTisFMAsYp6HTNdri6aay4oKzgQeAbKdrUY5oBu4EbvHlFzU5XUy00eDpAXvX63HgCKdrURG1DLhULwrsPt3V6gF71+so4HeADigV+5qAIuBADZ2e0RZPiJQVF4wFSoDhTteiwmIRVitnsdOFxAJt8YSIfYXqWGAaULOLyVX0qAcKsMa7WuxwLTFDWzxhUFZcsDtwO3A+IA6Xo7pvAVYrJ+77zwk1DZ4wKisu+AlwN3CI07WoLqkBfg/c7csv0nHYwkCDJ8zKigsEayDB24GBDpejOtYIPAIU+fKL1jhdTCzT4ImQsuKCdOBm4LdAisPlqB01Af8B/myfqVRhpsETYfa1P3cAZztdiyIAPAn8yZdftNLpYuKJBo9DyooLDgSuB84FkpytJu40A08DhfE+2oNTNHgcVlZcMADIB64EBjhcTqxrBp7DCpzlThcTzzR4XKKsuCAZq/VzHXCgw+XEmiqsXgX+6csv+tLpYpQGjyuVFRdMwtoNOwW9yLO7DDATeBT4ry+/SC/qdBENHhcrKy7YC7gGuBjo43A50WIl1hmq/+gZKvfS4IkCZcUFCcDhwGnAqcAgRwtyn2rgBeAxYLYvv0g/1C6nwROFyooLxvBjCI1xshYH1QGzgaeAF3z5RX6H61FdoMET5ezrgk7DCqHDgQRHCwqvL4B37J/ZvvyiWofrUd2kwRNDyooL+mANRjgBOBQYBSQ6WlT3GawOt+baP+/78ovWOVuSChUNnhhWVlyQgnVq/hCsDupHYfUX5LYwagRWAaXAUqygmefLLyp3sigVPho8caasuCAR2BcYCRyAFUQ+oD/QD+vsWTi68qjDOuNU2sbP9778okAY1qlcSoNH7aCsuMAL9OXHIOrf6vcsrM6x6rHCZFe/bwNWAD/o2SbVQoNHKRVxelWsUiriNHiUUhGnwaOUijgNHpcSESMiTwQ9ThCRTSLympN1KRUKGjzu5QdGikiq/fg4YG1XFiAisXwVs4piGjzu9iZwkv37eVi95gEgIoeIyHwRWWT/u6/9/CUi8ryIvIp1a4FSrqPB427PAOeKSArWVcfBw+YuB44wxhwI/BH4a9Br44GLjTFHR6xSpbpAm+IuZoxZKiKDsVo7b7R6ORv4j4gMxbqvKfg2iHeNMVsjU6VSXactHvd7BfgHQbtZtj8DHxhjRgIns+OQOdpFhHI1bfG43yNAhTHmcxE5Muj5bH482HxJhGtSqke0xeNyxpgfjDF3t/HSHcBtIjIP8Ea4LKV6RO/VUkpFnLZ4lFIRp8GjlIo4DR6lVMRp8CilIk6DRykVcRo8SqmI0+BRSkWcBo9SKuI0eJRSEafBo5SKOA0epVTEafAopSJOg0cpFXEaPEqpiNPgUUpFnAaPUiriNHiUUhGnwaOUijgNHqVUxGnwKKUiToNHKRVx/w/ZH8lxxdE7pwAAAABJRU5ErkJggg==\n",
      "text/plain": [
       "<Figure size 864x360 with 1 Axes>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    },
    {
     "data": {
      "text/plain": [
       "<Figure size 432x288 with 0 Axes>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "f, bx = plt.subplots(figsize=(12,5))\n",
    "transporte = ['Aire', 'Tren', 'Carretera', 'Mar']\n",
    "porcentajes = [2389, 3381, 2598, 10688]\n",
    "colores = ['lightcoral','palevioletred','sandybrown','darksalmon']\n",
    " \n",
    "plt.pie(x=porcentajes, labels=transporte, colors = colores, autopct='%1.2f%%')\n",
    "plt.title('Peso de cada Medio de Transporte')\n",
    "plt.show()\n",
    "plt.savefig(\"Medio_Trans.png\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 289,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "<Figure size 432x288 with 0 Axes>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "plt.savefig(\"Medio_Trans.png\", bbox_inches='tight', dpi=300,)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### Valor total de importaciones y exportaciones\n",
    "\n",
    "1. Tomando en cuenta la suma de ambos, exportaciones e importaciones \n",
    "2. Tomando en cuenta con los flujos \n"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "##  **1.** "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 249,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>origin</th>\n",
       "      <th>total_value_expor</th>\n",
       "      <th>total_value_impor</th>\n",
       "      <th>balanza_comercial</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>5</th>\n",
       "      <td>China</td>\n",
       "      <td>3.297705e+10</td>\n",
       "      <td>1.223300e+10</td>\n",
       "      <td>2.074405e+10</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>6</th>\n",
       "      <td>France</td>\n",
       "      <td>1.861433e+10</td>\n",
       "      <td>1.316000e+09</td>\n",
       "      <td>1.729833e+10</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>18</th>\n",
       "      <td>USA</td>\n",
       "      <td>1.835531e+10</td>\n",
       "      <td>5.291000e+09</td>\n",
       "      <td>1.306431e+10</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>13</th>\n",
       "      <td>Russia</td>\n",
       "      <td>1.322300e+10</td>\n",
       "      <td>8.510000e+08</td>\n",
       "      <td>1.237200e+10</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>15</th>\n",
       "      <td>South Korea</td>\n",
       "      <td>1.462115e+10</td>\n",
       "      <td>3.889000e+09</td>\n",
       "      <td>1.073215e+10</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "         origin  total_value_expor  total_value_impor  balanza_comercial\n",
       "5         China       3.297705e+10       1.223300e+10       2.074405e+10\n",
       "6        France       1.861433e+10       1.316000e+09       1.729833e+10\n",
       "18          USA       1.835531e+10       5.291000e+09       1.306431e+10\n",
       "13       Russia       1.322300e+10       8.510000e+08       1.237200e+10\n",
       "15  South Korea       1.462115e+10       3.889000e+09       1.073215e+10"
      ]
     },
     "execution_count": 249,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "order=balanza_c.sort_values('balanza_comercial', ascending=False)\n",
    "order.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 215,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "215691298000.0"
      ]
     },
     "execution_count": 215,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "sum_exp_imp= sum(order['total_value_expor'])+ sum(order['total_value_impor'])\n",
    "sum_exp_imp\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 221,
   "metadata": {},
   "outputs": [],
   "source": [
    "#order['sum']= sum(order['total_value_expor'])+ sum(order['total_value_impor'])\n",
    "#order"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 246,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "origin               ChinaFranceUSARussiaSouth KoreaCanadaGermanyNe...\n",
       "total_value_expor                                          1.29305e+11\n",
       "total_value_impor                                           2.9667e+10\n",
       "balanza_comercial                                          9.96381e+10\n",
       "sum                                                        1.94122e+12\n",
       "dtype: object"
      ]
     },
     "execution_count": 246,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "ochenta_p=order.iloc[0:9,:].sum(axis=0)\n",
    "ochenta_p\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 247,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "158972116000.0"
      ]
     },
     "execution_count": 247,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "tot_p=ochenta_p[1] + ochenta_p[2]\n",
    "tot_p"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 248,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "0.7370353717283485"
      ]
     },
     "execution_count": 248,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "ochenta_por_pais=tot_p/sum_exp_imp\n",
    "ochenta_por_pais"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 2. "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 251,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>origin</th>\n",
       "      <th>total_value_expor</th>\n",
       "      <th>total_value_impor</th>\n",
       "      <th>balanza_comercial</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>5</th>\n",
       "      <td>China</td>\n",
       "      <td>3.297705e+10</td>\n",
       "      <td>1.223300e+10</td>\n",
       "      <td>2.074405e+10</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>6</th>\n",
       "      <td>France</td>\n",
       "      <td>1.861433e+10</td>\n",
       "      <td>1.316000e+09</td>\n",
       "      <td>1.729833e+10</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>18</th>\n",
       "      <td>USA</td>\n",
       "      <td>1.835531e+10</td>\n",
       "      <td>5.291000e+09</td>\n",
       "      <td>1.306431e+10</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>13</th>\n",
       "      <td>Russia</td>\n",
       "      <td>1.322300e+10</td>\n",
       "      <td>8.510000e+08</td>\n",
       "      <td>1.237200e+10</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>15</th>\n",
       "      <td>South Korea</td>\n",
       "      <td>1.462115e+10</td>\n",
       "      <td>3.889000e+09</td>\n",
       "      <td>1.073215e+10</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "         origin  total_value_expor  total_value_impor  balanza_comercial\n",
       "5         China       3.297705e+10       1.223300e+10       2.074405e+10\n",
       "6        France       1.861433e+10       1.316000e+09       1.729833e+10\n",
       "18          USA       1.835531e+10       5.291000e+09       1.306431e+10\n",
       "13       Russia       1.322300e+10       8.510000e+08       1.237200e+10\n",
       "15  South Korea       1.462115e+10       3.889000e+09       1.073215e+10"
      ]
     },
     "execution_count": 251,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "order=balanza_c.sort_values('balanza_comercial', ascending=False)\n",
    "order.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 253,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "104635298000.0"
      ]
     },
     "execution_count": 253,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "sum_bal= sum(order['balanza_comercial'])\n",
    "sum_bal"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 278,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "origin               ChinaFranceUSARussiaSouth KoreaCanada\n",
       "total_value_expor                              1.08475e+11\n",
       "total_value_impor                               2.4149e+10\n",
       "balanza_comercial                              8.43258e+10\n",
       "dtype: object"
      ]
     },
     "execution_count": 278,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "ochenta_p=order.iloc[0:6,:4].sum(axis=0)\n",
    "ochenta_p\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 279,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "84325830000.0"
      ]
     },
     "execution_count": 279,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "tot_p=ochenta_p[3]\n",
    "tot_p"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 280,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "0.8059023256186454"
      ]
     },
     "execution_count": 280,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "ochenta_por_pais=tot_p/sum_bal\n",
    "ochenta_por_pais"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "R: China France USA Russia South Korea Canada"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.8.5"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 4
}
